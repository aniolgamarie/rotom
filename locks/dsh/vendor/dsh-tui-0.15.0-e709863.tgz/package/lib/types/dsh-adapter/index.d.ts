/**
 * dsh-tui plugin entry. The TUI implementation lives in `./plugin.tsx` (its
 * render path is JSX); this module owns the plugin surface (`name`/`inject`/
 * `Config`/`apply`) at the package entry module and delegates
 * `apply` through a dynamic import so entry-scanning tooling and the Loader
 * resolve a plain `.ts` module.
 * @module @deepseek-harness-tui/dsh-tui
 */
import type { Context } from '@deepseek-ai/cordis';
import Schema from '@deepseek-ai/schemastery';
import type { SessionModeSpec } from '../sessionModes.js';
import type { NotificationMethod, TaskNotifications } from '../ink/terminal-notification.js';
import { type KernelBackendId } from '../kernelPrefs.js';
import { type CodeFrameStyle, type ImageBacking, type MathImageBacking, type MathImageScale, type MathRendering, type PageMarginSetting, type ScrollGutterMode, type StatusBarConfig, type ToolBackground } from '../tuiDisplayPrefs.js';
import { type ShortcutActionId } from '../utils/keymap.js';
import { type SplashFontSetting } from '../components/splashFonts.js';
import { type BrandSetting } from '../branding.js';
import { type RuntimeConfig } from './compat/settings.js';
export declare const name = "dsh-tui";
export declare const inject: string[];
/**
 * dsh-tui plugin configuration: session attachment, model route, working
 * directory, and display preferences.
 */
export interface Config {
    /** Existing session to attach; a fresh session is created when absent. */
    sessionId?: string;
    /** Agent backend the session runs on: `dsh` (default), the DeepSeek
     *  Harness agent; `claude`, the experimental Claude Agent backend driving
     *  the local Claude CLI through the Claude Agent SDK (optional peer
     *  `@anthropic-ai/claude-agent-sdk`); `codex`, the experimental Codex
     *  backend driving the user's own `codex` CLI over `codex app-server`.
     *  `dsh-tui --backend <id>` sets it through `DSH_TUI_BACKEND`.
     *
     *  A plain `string` on purpose: this is the **input** surface, so an embedder
     *  writing `{ backend: 'codex' }` keeps compiling. The schema normalizes syntax;
     *  the boot checks registry membership after assembling installed bundles.
     *  The `BackendId` brand stays inside the package, where it guards session
     *  refs and `~/.dsh-tui/backends/<id>/` paths. Declaring the
     *  branded `KernelBackendId` here breaks published consumers instead
     *  (PR #1380 review R1). */
    backend?: string;
    /** LLM provider route. The route resolves atomically (issue #67): the
     *  `/model` choice persisted in `~/.dsh-tui/model.json` — the route the
     *  last session ran — wins whole; otherwise a `provider`+`model` pair named
     *  here is the deployment DEFAULT; otherwise `agentDefaultModel` supplies
     *  the provider-neutral Harness default. A bare embedder without that
     *  service falls back to DeepSeek. A half-pinned pair (only one of the two
     *  keys) is ignored outright and never half-overrides the persisted
     *  choice. */
    provider?: string;
    /** Model override passed to the agent; resolved together with `provider`
     *  as one atomic route (see `provider`). */
    model?: string;
    /** Session working directory. When absent, the git worktree root
     *  containing the invoking directory wins (the invoking directory itself
     *  outside any worktree) — never a bare launch subdirectory (issue #96). */
    cwd?: string;
    /** Absolute local path, file URL, or provider URI resolved before the
     *  initial agent is created. */
    workspace?: string;
    /** Reasoning effort applied to every request, validated against the live
     *  route's adapter levels (an unlisted level is ignored and the adapter
     *  default applies). This is the deployment DEFAULT beneath the persisted
     *  `/effort` choice (the level the last session ran); it also seeds the
     *  startup status line until the first request header reports the live
     *  value. */
    effort?: string;
    /** Settings user-layer default for future sessions; when set it outranks
     *  both the persisted `/effort` choice and the `effort` fallback. */
    effortDefault?: string;
    /** Show the header whale and its idle animation. */
    whale?: boolean;
    whaleIdle?: boolean;
    /** Big-text face on the header splash (settings `dsh-tui.splashFont`):
     *  `daily` (the default) rotates by local date, any other value is a font
     *  id from `components/splashFonts.ts` (`bold`/`square`/…) pinning that one
     *  face. An unknown value falls back to `daily`. */
    splashFont?: SplashFontSetting;
    /** Brand look of the splash and theme (settings `dsh-tui.brand`): `auto`
     *  (the default) follows the active backend — Claude boots orange;
     *  `deepseek`/`claude` pin one look. Junk normalizes to `auto`. */
    brand?: BrandSetting;
    /** Swap the header's pixel whale for the static maid portrait. */
    whaleGirl?: boolean;
    /** Reduce decorative header content and colors. */
    minimal?: boolean;
    /** Show the live working line derived in-process from base session events. */
    activity?: boolean;
    /** Working-activity indicator preset (`moon8`/`moon`/`comet`/`dots`/…
     *  or `random`; see activityFrames.ts). When absent, the `/activity`
     *  choice persisted in `~/.dsh-tui/working-activity.json` wins, then the
     *  `moon8` default. */
    activityFrames?: string;
    /** Show the segmented context bar (the band under the input with the
     *  `ctx used/window` readout) in the status footer; off hides that row
     *  while the status/mode lines stay (issue #29). */
    contextBar?: boolean;
    /** Run in the terminal's alternate screen (full-screen terminal layout).
     *  Defaults to true — the fullscreen surface is the more complete one
     *  (mouse, timeline rail, scrollbar gutter, selection copy), so fresh
     *  installs start there; cordis.yml `fullscreen: false` or a /settings
     *  toggle opts back into the inline main-screen layout. */
    fullscreen?: boolean;
    /** Allow terminal image previews when supported (default true). Saved
     *  /settings choices override this value after restart. The environment
     *  override DSH_TUI_DISABLE_TERMINAL_IMAGES can always force previews off. */
    terminalImages?: boolean;
    /** Launchpad landing page (settings `dsh-tui.launchpad`): an ordinary
     *  launch (no --resume, no first prompt) starts on the launchpad — the
     *  page where the first sentence gets typed. On by default; `false` boots
     *  straight into the chat page. Saved /settings choices override this
     *  value after restart; DSH_TUI_NO_LAUNCHPAD=1 skips it regardless. */
    launchpad?: boolean;
    /** UI language: `en` / `zh`. When absent, the `DSH_TUI_LANG` env var wins,
     *  then the `/lang` choice persisted in `~/.dsh-tui/lang.json`, then `zh`. */
    lang?: string;
    /** Agent preset id new sessions compose from (standard/ptc/minimal/
     *  cordis/… when the roster is mounted). A `DSH_TUI_PRESET` launch
     *  instruction outranks everything; otherwise the `/preset` choice
     *  persisted in `~/.dsh-tui/agent-preset.json` wins, then this value as
     *  the deployment default, then the roster default (`standard`). */
    preset?: string;
    /** Edit/Write diff presentation: `auto` picks side-by-side on wide
     *  terminals (≥110 cols) and unified below; `split`/`unified` force one
     *  layout. Editable live from the `/settings` screen. */
    diffLayout?: 'auto' | 'split' | 'unified';
    /** Thinking-block display: `preview` (default) streams a 2-3 line live
     *  preview and folds each step when it settles; `full` keeps thinking
     *  expanded until the whole turn ends. Editable live from `/settings`. */
    thinkingFold?: 'preview' | 'full';
    /** Grouping/folding of consecutive background-job cards: `auto` (default)
     *  groups any run of ≥2 adjacent job cards and folds a run of 3+ into its
     *  summary line once every member settled; `always` folds any run of 2+
     *  immediately; `never` never folds on its own (a click on the group
     *  header still folds one run). Editable live from `/settings`. */
    jobGroupFold?: 'auto' | 'always' | 'never';
    /** Tool-card background strength; defaults to no added background. */
    toolBackground?: ToolBackground;
    /** What the fullscreen transcript's right gutter shows (settings
     *  `dsh-tui.scrollGutter`): `timeline` turn rail (default), `scrollbar`
     *  proportional thumb, or `hidden`. */
    scrollGutter?: ScrollGutterMode;
    /** Root page inset (settings `dsh-tui.pageMargin`): a preset name
     *  (`none` / `slim` / `normal` (default) / `roomy`) or a custom `NxM`
     *  spec (columns per side × rows top/bottom) that insets the whole UI
     *  from the terminal edges. Terminals without their own viewport padding
     *  (bare WSL, tmux, SSH) otherwise hug the screen border. */
    pageMargin?: PageMarginSetting;
    /** Terminal-card header folding (settings `dsh-tui.foldTerminalCommand`):
     *  `true` collapses a multi-line command title to its first line plus a
     *  `+N lines` hint; Ctrl+O / clicking the card expands it. Default off —
     *  the full title keeps rendering. */
    foldTerminalCommand?: boolean;
    /** Turn-usage ledger row (settings `dsh-tui.turnUsageRow`): the quiet
     *  right-aligned line that closes each turn in the transcript (tokens
     *  in/out, cache split, span, retries). Off by default; the ledger data
     *  feeds /tokens, /status and the footer hover regardless. */
    turnUsageRow?: boolean;
    /** Show the session name as a chip on the prompt top border's right side
     *  (settings `dsh-tui.promptSessionLabel`); off by default. */
    promptSessionLabel?: boolean;
    /** Fullscreen draft editor (settings `dsh-tui.expandEditor`): the ⛶
     *  affordance in the input row and the expandEditor shortcut (default
     *  Ctrl+Shift+E) expand the draft into a whole-screen editor. On by
     *  default; off removes both entry points. */
    expandEditor?: boolean;
    /** Smooth streaming reveal (settings `dsh-tui.smoothStreaming`): live
     *  assistant text, expanded thinking, and tool call bodies paint through
     *  a ~30fps reveal instead of jumping per provider burst — bursty or
     *  one-shot deliveries read as an even flow. On by default. */
    smoothStreaming?: boolean;
    /** Successful task notifications: off, unfocused (default), or always. */
    taskNotifications?: TaskNotifications;
    /** Terminal notification transport: auto (default), OSC 9, or BEL. */
    notificationMethod?: NotificationMethod;
    /** Mermaid diagrams (settings `dsh-tui.mermaidDiagrams`): ```mermaid
     *  fences in replies render as Unicode box-drawing art — flowcharts,
     *  sequence/state/class/ER diagrams, pie, mindmap, timeline, gitGraph —
     *  laid out in-process, no browser or image protocol. A diagram wider
     *  than the viewport or of an unsupported type keeps the fenced source.
     *  On by default; off always shows the source. */
    mermaidDiagrams?: boolean;
    /** Code-frame shape (settings `dsh-tui.codeFrameStyle`): `light`
     *  (default) is the open rail frame — corner + language label on top,
     *  a left rail with one padding column per row, no right wall or
     *  bottom edge; `full` closes the box with a right wall (continuous
     *  across wrapped rows) and a bottom edge. The narrow fallback (net
     *  body width < 8) always stays the plain ANSI fence. */
    codeFrameStyle?: CodeFrameStyle;
    /** LaTeX math (settings `dsh-tui.mathRendering`): `$…$` / `\(…\)` inline
     *  and `$$…$$` / `\[…\]` blocks in replies. `auto` (default) uses the best
     *  available renderer — today Unicode text: Greek and operator symbols,
     *  scripts, fractions and operator limits stacked in display blocks,
     *  matrices, cases; `unicode` pins it; `source` always shows the TeX.
     *  Unsupported, still-streaming, or too-wide formulas keep their source. */
    mathRendering?: MathRendering;
    /** Display-formula image size (settings `dsh-tui.mathImageScale`), used
     *  with `mathRendering: image`: `auto` matches the body text, `large` and
     *  `xlarge` set display math bigger — which also hands the terminal more
     *  device pixels per stroke, the only sharpness lever a terminal image has.
     *  Inline formulas keep the base scale. */
    mathImageScale?: MathImageScale;
    /** Formula-image backing (settings `dsh-tui.mathImageBacking`): `transparent`
     *  paints only the formula and lets the terminal background show through;
     *  `terminal` composites it onto the terminal's background colour. */
    mathImageBacking?: MathImageBacking;
    /** Transcript-image backing (settings `dsh-tui.imageBacking`): `transparent`
     *  floats photos and illustrations on whatever the terminal shows;
     *  `terminal` composites them onto the terminal's background colour. */
    imageBacking?: ImageBacking;
    /** @deprecated Use `mathRendering`; `false` still means `source`. */
    latexMath?: boolean;
    /** Auto recap on open (settings `dsh-tui.recapOnOpen`): opening or resuming a
     *  session summarizes its recent activity into a dim line at the bottom of
     *  the transcript. On by default; off leaves `/recap` as the manual path. */
    recapOnOpen?: boolean;
    /** Status-footer field visibility and compact presentation preferences. */
    statusBar?: Partial<StatusBarConfig>;
    /** Side panel (settings `dsh-tui.sidePanel.*`): the two-column layout's
     *  master switch, its startup state, the chat-column fraction, and the
     *  enabled panels in PanelBar order. Every member is normalized at parse
     *  time, so a hand-edited value can never wedge the layout. */
    sidePanel?: {
        /** Master switch of the split layout; on by default. Off makes /panel
         *  and Ctrl+B fall back to the fullscreen panels. */
        splitEnabled?: boolean;
        /** Whether a session opens with the sidebar expanded (off by default, so
         *  the upgrade leaves the layout alone); Ctrl+B toggles it live. */
        open?: boolean;
        /** Chat column as a fraction of the content width, clamped to 0.1–0.95
         *  (default 0.68); +/- while the panel is focused nudges it live. */
        ratio?: number;
        /** Enabled panel ids, comma-separated, in PanelBar order (default:
         *  all eight built-in panels). A
         *  malformed id is dropped, an unknown one survives for a plugin. */
        panels?: string;
    };
    /** Companion pet (settings `dsh-tui.companion.*`): which skin the panel
     *  pet wears. */
    companion?: {
        /** 'deepy' (default, the deepy whale kit) or 'whale' (the splash's
         *  layered pixel whale). Unknown ids normalize to deepy. */
        skin?: string;
    };
    /** btw thread context (settings `dsh-tui.btw.*`): how much of the side
     *  thread follows into the next ask. Members normalize (turns clamp
     *  1-8, budget clamps 1k-200k), so junk cannot wedge the thread. */
    btw?: {
        /** Completed Q/A pairs carried into a follow-up ask, 1-8 (default 4). */
        contextTurns?: number;
        /** Total character budget of that carried context (default 24000;
         *  the per-answer cap derives internally as min(8k, budget/2)). */
        contextBudget?: number;
    };
    /** Built-in action-shortcut overrides (`paste: 'alt+v'`), keyed by action
     *  id (see the keymap utility). Combos are `ctrl+`/`alt+`/`shift+` plus a
     *  key; several combos may be comma-separated. Unset actions keep their
     *  defaults; the `/settings` screen edits the same keys live (its user
     *  layer wins over this file). */
    shortcuts?: Partial<Record<ShortcutActionId, string>>;
    /** Shift+Tab session-mode cycle (array order IS the cycle order; index 0
     *  is the unmarked base mode). Each entry bundles any subset of the
     *  `plan`/`sandbox`/`approval` atoms; absent → the built-in
     *  default/plan/full cycle (see sessionModes.ts). */
    modes?: SessionModeSpec[];
    /** Upstream auto-retry for DSH sessions (default on): seed a retry
     *  policy (5 attempts, transport-drop-aware failure codes) on the
     *  llm-pi-ai provider route the bound session actually uses whenever
     *  it declares no retryPolicy, through the llm-pi-ai settings section
     *  — the policy the kernel's llm-retry plugin executes. Dormant
     *  channels are never written; routes with an explicit retryPolicy are
     *  never overwritten; setting this to false opts out entirely. */
    upstreamRetry?: boolean;
}
/** The complete two-stage parse: syntax, then registry membership (P0 D1).
 *  Empty, malformed or unregistered values mean "not configured". Unlike the
 *  syntax-only Config schema, this helper requires discovery to have run. */
export declare function normalizeBackendChoice(value: unknown): KernelBackendId | undefined;
export declare const Config: Schema<Config, RuntimeConfig<Config>>;
/**
 * Start the interactive TUI front door, delegating to the JSX implementation
 * in `./plugin.tsx` (see its module doc for the full contract).
 * @param ctx - the plugin context.
 * @param config - the validated dsh-tui configuration.
 * @returns a promise settling when the Loader entry has scheduled its runtime.
 */
export declare function apply(ctx: Context, config: RuntimeConfig<Config>): Promise<void>;
export { BACKEND, BACKEND_CAPABILITY_NAMES, BACKEND_RESERVED_IDS, validateBackendSpec, type BackendInstallRecipe, type BackendSpec, } from '../adapter/spec/tui-contributions.js';
export { backendAdmission, type BackendAdmission, type BackendAdmissionHost } from './backend-admission.js';
export { backendContributionOf } from './backend-contribution.js';
//# sourceMappingURL=index.d.ts.map