import type { DOMElement } from './dom.js';
import type { TextDecoration } from './styles.js';
import type { Rectangle } from './layout/geometry.js';
import type { SoftWrapFlag } from './output.js';
/**
 * Cached layout bounds for each rendered node (used for blit + clearing).
 * `top` is the yoga-local getComputedTop() — stored so ScrollBox viewport
 * culling can skip yoga reads for clean children whose position hasn't
 * shifted (O(dirty) instead of O(mounted) first-pass).
 */
export type CachedLayout = {
    x: number;
    y: number;
    width: number;
    height: number;
    top?: number;
    /** Effective background color (own ?? inherited) at the last render.
     *  Renderer compares it per frame so a background change refuses the
     *  prevScreen blit — children would otherwise resurrect the stale color
     *  (stuck hover highlight). */
    bg?: string;
    /** Whether the node fills its whole rect (own backgroundColor or
     *  `opaque`). Only such an absolute node "covers" cells a previous
     *  overlay vacated; a transparent one leaves them stale (see
     *  hasOverlayVacatedCells). */
    opaque?: boolean;
};
/** Layout bounds cached per rendered node, used for blitting and clearing. */
export declare const nodeCache: WeakMap<DOMElement, CachedLayout>;
/** One run of rows sharing a noSelect width, in node-relative rows. */
export type TextNoSelectRun = {
    /** First decorated row (0 = the header row when one is painted). */
    offset: number;
    height: number;
    /** Leading columns of each row in the run to exclude from selection. */
    width: number;
};
/** Current prepared text only: scrolling changes its position, not its lines.
 * Weak keys release unmounted nodes; mutations discard the previous version.
 * `decoration` participates in the hit check (producers memo the object);
 * `noSelectRuns` are re-pushed every frame — the write happens on the hit
 * path too, but the screen bitmap is reset per frame. */
export declare const textPaintCache: WeakMap<DOMElement, {
    maxWidth: number;
    background: string | undefined;
    paddingLeft: number;
    paddingTop: number;
    text: string;
    lines: readonly string[];
    softWrap: SoftWrapFlag[] | undefined;
    decoration: TextDecoration | undefined;
    noSelectRuns: readonly TextNoSelectRun[] | undefined;
}>;
/** Rects of removed children that need clearing on next render */
export declare const pendingClears: WeakMap<DOMElement, Rectangle[]>;
/**
 * Register a removed child's rect for clearing on the next render, and
 * flag the next frame when the removed node was absolutely positioned.
 * @param parent - the parent whose removed child rect to record.
 * @param rect - the removed child's last known bounds.
 * @param isAbsolute - whether the removed child was absolutely positioned; disables blit next frame.
 */
export declare function addPendingClear(parent: DOMElement, rect: Rectangle, isAbsolute: boolean): void;
/**
 * Read and clear the absolute-removal flag set by addPendingClear.
 * @returns whether an absolutely positioned node was removed since the last render.
 */
export declare function consumeAbsoluteRemovedFlag(): boolean;
//# sourceMappingURL=node-cache.d.ts.map