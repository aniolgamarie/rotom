import { Event } from './event.js';
/**
 * Terminal resize event. Not yet dispatched by the renderer; declared for
 * the event-handler props surface.
 */
export declare class ResizeEvent extends Event {
    /** The new terminal width in columns. */
    readonly columns: number;
    /** The new terminal height in rows. */
    readonly rows: number;
    constructor(columns: number, rows: number);
}
//# sourceMappingURL=resize-event.d.ts.map