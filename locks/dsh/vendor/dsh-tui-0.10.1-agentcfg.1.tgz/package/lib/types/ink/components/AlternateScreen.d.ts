import React, { type PropsWithChildren } from 'react';
type Props = PropsWithChildren<{
    mouseTracking?: boolean;
}>;
/** Own the alternate buffer and its input modes for the lifetime of this subtree. */
export declare function AlternateScreen({ children, mouseTracking }: Props): React.JSX.Element;
export {};
//# sourceMappingURL=AlternateScreen.d.ts.map