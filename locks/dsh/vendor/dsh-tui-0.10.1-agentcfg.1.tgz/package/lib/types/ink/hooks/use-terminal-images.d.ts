import type { TerminalCellSize } from '../terminal-image.js';
interface TerminalImages {
    subscribe(listener: () => void): () => void;
    getSnapshot(): boolean;
    getCellSize?(): TerminalCellSize | undefined;
    request(): () => void;
}
/** Only measured pixels qualify for an original-pixel (100%) image view. */
export declare function useTerminalImageCellSize(): TerminalCellSize | undefined;
export declare const TerminalImagesContext: import("react").Context<TerminalImages>;
/** Request the renderer's capability probe before reading or decoding pixels. */
export declare function useTerminalImages(requested?: boolean): boolean;
export {};
//# sourceMappingURL=use-terminal-images.d.ts.map