import { type TerminalSize } from '../components/TerminalSizeContext.js';
/** Terminal dimensions from the Ink app shell.
 * @returns the current terminal dimensions.
 */
export declare function useTerminalSize(): TerminalSize;
//# sourceMappingURL=use-terminal-size.d.ts.map