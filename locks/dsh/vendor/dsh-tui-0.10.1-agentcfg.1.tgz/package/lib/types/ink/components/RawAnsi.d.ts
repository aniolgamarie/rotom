import React from 'react';
type Props = {
    lines: string[];
    width: number;
};
/** Already wrapped terminal rows, measured without creating a tree per style span. */
export declare const RawAnsi: React.MemoExoticComponent<({ lines, width }: Props) => React.JSX.Element | null>;
export {};
//# sourceMappingURL=RawAnsi.d.ts.map