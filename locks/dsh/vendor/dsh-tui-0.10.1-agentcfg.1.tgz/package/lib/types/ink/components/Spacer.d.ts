import React from 'react';
/** Consume unused space on the parent's flex axis. */
export default function Spacer(): React.JSX.Element;
//# sourceMappingURL=Spacer.d.ts.map