import { type Props } from '../components/AppContext.js';
/**
 * Access this Ink app's output stream and manual exit handler.
 */
declare const useApp: () => Props;
export default useApp;
//# sourceMappingURL=use-app.d.ts.map