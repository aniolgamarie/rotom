import type { DOMElement } from './dom.js';
/** Hard bounds for one decoded image admitted to the terminal renderer. */
export declare const TERMINAL_IMAGE_MAX_EDGE = 1024;
export declare const TERMINAL_IMAGE_MAX_BYTES: number;
/** Explicit large previews may use a longer edge, but not an unbounded square. */
export declare const TERMINAL_IMAGE_PREVIEW_MAX_EDGE = 2048;
export declare const TERMINAL_IMAGE_PREVIEW_MAX_BYTES: number;
/** Maximum decoded RGBA bytes represented by placements in one frame. */
export declare const TERMINAL_IMAGE_MAX_FRAME_BYTES: number;
/**
 * Cell-box cap for one placement (a 128×128 grid). Pixel payload is bounded
 * separately by MAX_EDGE / MAX_BYTES / MAX_FRAME_BYTES; this only bounds the
 * screen area one image may claim, so a modal preview can fill a large
 * transcript while thumbnails and status views keep their own small boxes.
 */
export declare const TERMINAL_IMAGE_MAX_CELLS: number;
export declare const TERMINAL_IMAGE_MAX_PLACEMENTS = 64;
export declare const SIXEL_MAX_ENCODED_BYTES: number;
export declare const SIXEL_THUMBNAIL_FRAME_BYTES: number;
export declare const SIXEL_CACHE_BYTES: number;
export declare const SIXEL_CACHE_ENTRIES = 64;
/** Pixel dimensions of one terminal cell. */
export interface TerminalCellSize {
    readonly width: number;
    readonly height: number;
}
/** Conventional monospace cell used when XTWINOPS pixel queries are absent. */
export declare const DEFAULT_TERMINAL_CELL_SIZE: TerminalCellSize;
/**
 * Immutable decoded image data accepted by the host image primitive.
 *
 * The renderer hashes `data` once per buffer and caches the digest by buffer
 * identity, so an in-place rewrite of the same buffer is never detected.
 * Callers must not mutate or refill `data` after passing it to `<Image>`;
 * changed pixels require a new `Uint8Array` (and therefore a new source
 * snapshot).
 */
export interface TerminalImageSource {
    /** Immutable row-major sRGB pixels, four bytes per pixel in RGBA order. */
    readonly data: Uint8Array;
    readonly width: number;
    readonly height: number;
}
/** One laid-out image request collected from the current Ink frame. */
export interface TerminalImagePlacement {
    readonly node: DOMElement;
    readonly x: number;
    readonly y: number;
    readonly columns: number;
    readonly rows: number;
    readonly source: TerminalImageSource;
    readonly presentation?: 'preview' | 'transcript';
    /** Visible terminal cells, while x/y/columns/rows retain the full layout box. */
    readonly clip?: {
        readonly x: number;
        readonly y: number;
        readonly columns: number;
        readonly rows: number;
    };
    readonly background?: string;
    /** False while a protocol-specific raster is pending or unavailable. */
    readonly graphicsReady?: boolean;
    /** Later paint operations cover this backing, including blank overlays. */
    readonly occluded?: boolean;
}
/**
 * Normalize terminal-reported cell pixels before they reach allocation math.
 * The upper bound rejects corrupt or injected XTWINOPS replies; real terminal
 * cells remain far below it, including HiDPI displays.
 */
export declare function normalizeTerminalCellSize(value: TerminalCellSize | undefined): TerminalCellSize;
/** Prefer a direct cell report, then derive it from text-area pixels. */
export declare function resolveTerminalCellSize(cell: TerminalCellSize | undefined, window: TerminalCellSize | undefined, columns: number, rows: number): TerminalCellSize | undefined;
/**
 * Prepare an RGBA raster that fits a laid-out cell rectangle without
 * distortion. The transparent canvas has the terminal rectangle's physical
 * aspect ratio; the host only downsamples source pixels and centers them
 * inside it. Kitty can then scale that bounded canvas to the requested cells.
 */
export declare function fitTerminalImageSource(source: TerminalImageSource, columns: number, rows: number, cellSize?: TerminalCellSize, presentation?: TerminalImagePlacement['presentation']): TerminalImageSource;
/** Validate an untrusted decoded source without copying its pixel buffer. */
export declare function isTerminalImageSource(value: unknown, presentation?: TerminalImagePlacement['presentation']): value is TerminalImageSource;
/** Recover and validate a source stored as primitive Ink host attributes. */
export declare function terminalImageSourceFromAttributes(attributes: Readonly<Record<string, unknown>>): TerminalImageSource | undefined;
//# sourceMappingURL=terminal-image.d.ts.map