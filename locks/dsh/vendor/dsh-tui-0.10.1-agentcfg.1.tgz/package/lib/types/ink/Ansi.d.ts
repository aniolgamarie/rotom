import React from 'react';
type Props = {
    children: string;
    dimColor?: boolean;
};
/** Project parser actions onto text leaves; control-only input has no layout. */
export declare const Ansi: React.MemoExoticComponent<({ children, dimColor }: Props) => React.JSX.Element | null>;
export {};
//# sourceMappingURL=Ansi.d.ts.map