import type { LocalCommand, LocalizedDescriptions, CommandCompletion } from './adapter/ports/channel-catalog.js';
export type { LocalCommand, LocalizedDescriptions, CommandCompletion } from './adapter/ports/channel-catalog.js';
/** One child in a slash-command tree contributed by a local feature/plugin. */
export interface CommandCompletionNode {
    name: string;
    aliases?: readonly string[];
    description: string;
    descriptions?: LocalizedDescriptions;
    tag?: string;
    /** Optional i18n key; plugin nodes normally rely on fallback text. */
    descriptionKey?: string;
}
export type CommandChildren = (canonicalPath: readonly string[]) => readonly CommandCompletionNode[];
/**
 * Whether a value can occupy one command-completion token. Keep this aligned
 * with the grammar accepted by {@link completeCommands}; callers that need an
 * empty prefix handle that case separately.
 */
export declare function isCommandCompletionToken(value: string): boolean;
/**
 * The built-in slash commands (name + description pairs). Plugin-registered
 * commands merge in at runtime; locals win on name collisions.
 */
export declare const LOCAL_COMMANDS: LocalCommand[];
/**
 * Hidden slash commands: intentionally not exposed in the `/` suggestion
 * menu or Help, but still recognized as local commands when typed. They are
 * kept out of `LOCAL_COMMANDS` so `filterCommands`/`completeCommands` never
 * surface them; dispatch recognizes them via {@link HIDDEN_COMMAND_NAMES}.
 */
export declare const HIDDEN_COMMANDS: readonly LocalCommand[];
/** Names of hidden commands, for fast dispatch/lookup. */
export declare const HIDDEN_COMMAND_NAMES: ReadonlySet<string>;
/**
 * Whether the input names a hidden command (same slash-optional trimming
 * rules as {@link isLocalCommandName}).
 */
export declare function isHiddenCommandName(input: string): boolean;
/**
 * Resolve a command's description in the active UI language. The en text in
 * `LOCAL_COMMANDS` (and the registry's own text for external commands) is
 * the fallback; zh translations live in the i18n dict under
 * `cmd-desc-<name>`. Resolved at call time — components call this during
 * render, so a `/lang` switch repaints descriptions immediately.
 * @param command - The command whose description to localize.
 */
export declare function localizedDescription(command: LocalCommand & {
    descriptionKey?: string;
}): string;
/**
 * Parse a slash-command line into its name and the verbatim input following
 * the name (separator whitespace included) — the same split the DSH command
 * registry uses, so `/plan off` dispatches `plan` with ` off`.
 *
 * @param line - Complete candidate command line.
 * @returns The parsed name and raw input, or `undefined` when the line is
 *   not a command.
 */
export declare function parseCommandName(line: string): {
    name: string;
    rawInput: string;
} | undefined;
/**
 * Whether the input names a local command. Local commands must never be sent
 * to the model when typed alone; trailing whitespace is legal.
 * @param input - Candidate command line (slash optional).
 * @param list - Command list to match against; defaults to LOCAL_COMMANDS.
 * @returns True when the trimmed input names a command in `list`.
 */
export declare function isLocalCommandName(input: string, list?: readonly LocalCommand[]): boolean;
/**
 * Filter commands by a `/…` input prefix.
 * The prefix is the whole input after the slash, so `/plan off` matches
 * nothing and the overlay stays closed — Enter still dispatches through
 * `parseCommandName`.
 * @param input - Slash-command input; the prefix is the whole text after the slash.
 * @param list - Command list to filter; defaults to LOCAL_COMMANDS.
 * @returns Commands whose name starts with the prefix, in list order.
 */
export declare function filterCommands(input: string, list?: readonly LocalCommand[]): LocalCommand[];
/**
 * Complete an arbitrary slash-command path. Root commands come from the
 * ordinary DSH/TUI catalog; each resolved token asks the caller for its
 * children, so PromptInput never needs feature- or plugin-specific cases.
 */
export declare function completeCommands(input: string, roots?: readonly LocalCommand[], children?: CommandChildren): CommandCompletion[];
//# sourceMappingURL=commands.d.ts.map