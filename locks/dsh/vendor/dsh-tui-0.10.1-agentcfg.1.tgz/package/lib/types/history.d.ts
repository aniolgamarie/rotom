/** One persisted input-history entry. */
export type HistoryEntry = {
    text: string;
    /** Unix ms timestamp. */
    ts: number;
};
/**
 * Append an input to the persisted history, deduping the immediately
 * previous entry and capping the file at 200 entries.
 * @param text - Input to persist; blank inputs are ignored.
 * @returns Resolves once this entry is persisted; callers on the input path
 * intentionally discard it because persistence is best-effort.
 */
export declare function appendHistory(text: string): Promise<void>;
/**
 * Read the persisted history, newest first.
 * @returns The persisted entries in reverse-chronological order.
 */
export declare function loadHistory(): HistoryEntry[];
/**
 * Stable id for a history entry (keeps React keys distinct across identical texts).
 * @param entry - The history entry to hash.
 * @param index - Position in the currently rendered result list.
 * @returns A 12-char hex id derived from the entry text, timestamp, and index.
 */
export declare function historyEntryId(entry: HistoryEntry, index?: number): string;
//# sourceMappingURL=history.d.ts.map