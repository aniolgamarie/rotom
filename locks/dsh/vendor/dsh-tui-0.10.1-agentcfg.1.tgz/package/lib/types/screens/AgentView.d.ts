import React from 'react';
import type { ChannelUi as Channel } from '../adapter/channel/ui-policy.js';
import type { ApprovalSnapshot } from '../dsh-adapter/approvals.js';
/**
 * The agent view screen — `/agentview`, `/bg`. Replaces the conversation
 * like the session browser does; every session keeps running behind it.
 */
export declare function AgentView({ channel, home, approval, onApprove, returnSessionId, onClose, }: {
    channel: Channel;
    /** Home directory, for collapsing project paths to `~`. */
    home: string;
    /** The parked approval ask (any agent's), so a background session's
     *  permission prompt is answerable without leaving the view. */
    approval: ApprovalSnapshot | null;
    onApprove: (outcome: 'allowed-once' | 'rejected') => void;
    /** Set when the view was opened by backgrounding the attached session
     *  (← / `/bg`): the view shows a "conversation moved to the
     *  background" notice and the final Esc RETURNS to that conversation
     *  instead of merely closing. */
    returnSessionId?: string;
    onClose: () => void;
}): React.ReactNode;
//# sourceMappingURL=AgentView.d.ts.map