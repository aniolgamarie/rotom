import React from 'react';
import type { SubagentState } from '../dsh-adapter/subagents.js';
import type { ClickEvent } from '../ink/events/click-event.js';
export interface SubagentCardProps {
    subagent: SubagentState;
    focused?: boolean;
    onClick?(event: ClickEvent): void;
}
export declare function SubagentCard({ subagent, focused, onClick }: SubagentCardProps): React.ReactNode;
//# sourceMappingURL=SubagentCard.d.ts.map