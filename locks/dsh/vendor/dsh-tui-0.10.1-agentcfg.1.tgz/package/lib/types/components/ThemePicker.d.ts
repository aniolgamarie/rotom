import React from 'react';
import { type SelectOption } from './Select.js';
import type { TuiThemeHost } from '../dsh-adapter/themes.js';
/**
 * Build the full selectable list from the shared catalog: `auto`, built-ins,
 * static JSON themes, and optional plugin themes. Shared by ThemePicker (render)
 * and the /theme command (focus index), so both always see the same ordering.
 */
export declare function getThemeOptions(themeHost?: TuiThemeHost): SelectOption[];
/**
 * Color-theme picker in the ActivityPicker style: a permission-colored Pane
 * listing the `auto` pseudo-theme and built-in palettes first, followed by
 * static JSON and plugin themes — each row shows the display name, base and
 * three key color swatches; `❯` marks focus, `✓` the active theme. Enter
 * applies through the ThemeProvider setter (persists to ~/.dsh-tui/theme.json
 * and hot swaps), Esc cancels.
 */
export declare function ThemePicker({ focusIndex, currentTheme, themeHost, onPick, }: {
    focusIndex: number;
    currentTheme: string | undefined;
    /** Optional runtime theme host; static themes work without it. */
    themeHost?: TuiThemeHost;
    /** Mouse pick (fullscreen): clicked row's absolute index (Chat applies
     *  the same code path as the keyboard Enter). */
    onPick?: (index: number) => void;
}): React.ReactNode;
//# sourceMappingURL=ThemePicker.d.ts.map