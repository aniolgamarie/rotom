import React from 'react';
import type { ChannelUi as Channel } from '../adapter/channel/ui-policy.js';
import type { ComposerImageRef } from '../dsh-adapter/channel.js';
import type { TranscriptImage } from '../dsh-adapter/transcript-images.js';
/** Capabilities referenced by `text`, in first occurrence order. A raw token
 * restored from disk/history has no sidecar entry and therefore stays inert. */
export declare function composerImageRefsForText(text: string, stagedByToken: ReadonlyMap<string, string>): ComposerImageRef[];
/**
 * Imperative handle for the Chat-level Ctrl+C rule: Chat's useInput listener
 * runs BEFORE this component's (EventEmitter registration order), so Chat
 * asks the prompt whether it holds text (→ clear it) or not (→ arm the
 * double-press exit). Populated every render; null while unmounted.
 */
export interface PromptController {
    hasText(): boolean;
    /** Current capability-backed draft images in token order, without reads. */
    previewImages?(): readonly {
        image: TranscriptImage;
        title: string;
    }[];
    clear(): void;
    /**
     * Append `text` at the end of the input (external injection channel; see
     * dsh-adapter/inject-channel.ts). Unlike `fillText`, which replaces the
     * whole value, this accumulates — matching OpenCode's `tui.prompt.append`
     * so repeated editor sends build one prompt. Returns the resulting value.
     */
    append(text: string): string;
    /**
     * Copy the active mouse selection to the system clipboard (OSC 52 + the
     * native fallback) and KEEP the selection for further editing. Returns
     * true when a selection existed and consumed the key; Chat's Ctrl+C
     * branch calls this first, before its clear/exit semantics.
     */
    consumeSelectionCopy(): boolean;
    /** Toggle vim editing mode (`/vim`); returns the new state (true = on). */
    toggleVim(): boolean;
    /** True while vim mode is on (either submode). Esc belongs to vim then —
     *  Chat's working-turn Esc interrupt must yield in BOTH submodes. */
    vimActive(): boolean;
}
export interface PromptInputProps {
    channel: Channel;
    /** Keep the draft mounted while another prompt-slot panel owns the UI. */
    suspended?: boolean;
    /** Whether the `?` help menu is open (state lives in the Chat screen). */
    helpOpen: boolean;
    onToggleHelp(): void;
    /**
     * Execute a slash command (built-in or plugin-registered) with its raw
     * argument text; returns false when the input should be sent to the model.
     */
    onRunCommand(name: string, rawInput: string, images: readonly ComposerImageRef[]): boolean | Promise<boolean>;
    /** Message-selection mode (Shift+↑): the input ignores keys while active. */
    selectionActive: boolean;
    /**
     * External fill from the ctrl+r history dialog: when this prop changes to
     * a non-null string, the input replaces its value and moves the caret to
     * the end. The caller clears it via onFillConsumed once consumed.
     */
    fillText?: string | null;
    onFillConsumed?(): void;
    /** Double-tap Esc with an empty input: open the rewind picker. */
    onRewindRequest?(): void;
    /**
     * ← on an EMPTY prompt backgrounds this session and
     * opens the agent view (with text, ← moves the caret as usual).
     */
    onBackgroundRequest?(): void;
    /**
     * Background sessions waiting on the user (agent view "needs input" rows
     * excluding this session); the prompt footer shows the
     * "← N agents" hint when provided (hidden when undefined).
     */
    backgroundAgentsNeedingInput?: number;
    /** Filled with the live controller each render (see PromptController). */
    controllerRef?: React.RefObject<PromptController | null>;
    /**
     * The staged image the caret is on — at a token's start, where the whole
     * token inverts — or undefined once it leaves; reported whenever that changes (`'caret'`),
     * and again on every click on a token (`'click'`, even when unchanged) so
     * the caller can re-show a preview the user dismissed. `title` is the
     * token without brackets (`Image #2`). Reported as undefined while the
     * prompt is suspended and on unmount.
     */
    onCaretImage?(image: TranscriptImage | undefined, title: string | undefined, reason: 'caret' | 'click'): void;
    /**
     * True while the caller shows the caret-driven preview. Esc then goes to
     * `onDismissCaretPreview` ahead of every other Esc meaning (the ladder's
     * "close the image preview" rung): this input's listener runs before
     * Chat's, and the prompt is NOT inert under a caret preview.
     */
    caretPreviewOpen?: boolean;
    onDismissCaretPreview?(): void;
}
/**
 * dsh-TUI prompt input: rounded border box (top+bottom borders
 * only), `❯ ` prompt char (dimmed while a turn is working), the text with a
 * block cursor at the cursor position, and above it the slash-command /
 * file-completion suggestion card (SuggestionCard: rounded panel with the
 * selected row behind a `❯` pointer in the theme's `suggestion` color).
 *
 * Empty input: a solid block caret on a blank cell and nothing else — no
 * placeholder text, so the terminal-painted IME preedit (pinyin) at the
 * parked cursor can never be overlaid on anything.
 *
 * Multi-line: Shift+Enter inserts a newline; ↑/↓ move between lines while
 * the input spans multiple lines (history/command selection otherwise); the
 * visible window scrolls to keep the caret row on screen past
 * MAX_VISIBLE_LINES. Enter submits, backspace/delete edit, ←/→ move the
 * cursor, Tab completes the selected command, Ctrl+G opens the draft in the
 * external editor ($VISUAL/$EDITOR), Escape clears (or closes the help
 * menu), `?` toggles the help menu. Windows ConPTY pipelines deliver
 * whole lines with the Enter key lost: a trailing CR/LF in the input marks
 * a complete line to submit.
 *
 * Enter submits immediately even while the model is streaming — as a STEER
 * (Codex/pi semantics): the message is injected at the next step boundary
 * of the running turn and the agent continues without aborting; Tab instead
 * queues the message for after the turn (followup). Both appear in a
 * pending preview above the input until delivered. Alt+Up pulls the last
 * pending message back for editing; Esc (with pending messages while
 * working) interrupts the turn and delivers them right away; Ctrl+Enter
 * aborts the turn and sends the current input immediately.
 */
export declare function PromptInput({ channel, suspended, helpOpen, onToggleHelp, onRunCommand, selectionActive, fillText, onFillConsumed, onRewindRequest, onBackgroundRequest, backgroundAgentsNeedingInput, controllerRef, onCaretImage, caretPreviewOpen, onDismissCaretPreview, }: PromptInputProps): React.JSX.Element | null;
//# sourceMappingURL=PromptInput.d.ts.map