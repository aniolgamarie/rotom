import React from 'react';
import type { LlmModelInfo } from '../adapter/ports/channel-view.js';
import type { ModelGroupRow } from '../modelGroups.js';
/**
 * Model picker: a permission-colored Pane with
 * the rows as Select entries (❯ focus pointer, ✓ on the active row,
 * descriptions), plus the Enter/Esc hint line. The DSH agent's model is
 * fixed at creation time, so a selection notifies "restart to apply".
 *
 * Two levels: the top level lists **provider groups** (registry display
 * name + model count, ✓ on the current provider's row) and drills in with
 * Enter; the second level lists that group's models and switches with
 * Enter — the same live-fork path the flat picker always had. A
 * single-group catalog skips the top level entirely (showBack=false, plain
 * confirm/exit hint), so single-provider setups keep the pre-grouping UX.
 *
 * 长列表按焦点窗口化（Select 同款）：picker 经 OverlayAbove 浮层挂载后有
 * maxHeight 裁剪，全量渲染会让焦点行被裁掉（看不到焦点按 Enter）。
 */
export declare function ModelPicker(props: {
    /** Top level: provider groups; Enter/click drills into one. */
    groups: readonly ModelGroupRow[];
    focusIndex: number;
    /** Current route key — its group row carries the ✓ marker. */
    currentProvider: string;
    onPick?: (index: number) => void;
} | {
    /** Second level (or single-group fast path): one provider's models —
     *  or the mixed-provider recents list (`showProviderPrefix`). */
    models: readonly LlmModelInfo[];
    /** The group's display label as this pane's title (default: "Model"). */
    groupLabel?: string;
    /** Multi-group catalogs show the back hint; the fast path keeps the plain one. */
    showBack: boolean;
    /** Prefix each row with its provider (the recents group mixes providers). */
    showProviderPrefix?: boolean;
    focusIndex: number;
    /** `provider/model` of the current model — its row carries the ✓ marker. */
    currentModel: string;
    onPick?: (index: number) => void;
}): React.ReactNode;
//# sourceMappingURL=ModelPicker.d.ts.map