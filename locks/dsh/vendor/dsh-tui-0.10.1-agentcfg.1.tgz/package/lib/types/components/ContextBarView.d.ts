import React from 'react';
import type { Color } from '../ink/styles.js';
import { type ContextSegments } from '../screens/StatusMetrics.js';
/**
 * The hoverable JSX twin of `renderContextBar`: the same segmented context
 * bar (same largest-remainder column split, same label fallback ladder,
 * same free-segment readout), rendered as one Box per segment so each
 * carries its own mouse handlers. Hovering a segment reports its key (or
 * `free`) upward through `onHover`; the footer turns that into a detail
 * readout on its supplemental row.
 *
 * The component path follows the ANSI path's geometry: this exists so the bar
 * can react to the pointer, not to restyle it.
 */
export declare function ContextBarView({ segments, usedTokens, contextWindow, width, colors, onHover, }: {
    /** Used tokens per content type. */
    segments: ContextSegments;
    /** Total used tokens, driving the usage readout. */
    usedTokens: number;
    /** The context window size in tokens. */
    contextWindow: number;
    /** Total bar width in terminal columns. */
    width: number;
    /** Theme overrides for the free segment (light theme passes its own). */
    colors?: {
        freeFill: Color;
        freeText: Color;
    };
    /** Hover signal: a segment key (`system`…`tools`), `free`, or null on
     *  leave. Absent handlers render a static bar (tests, headless embeds). */
    onHover?: (segment: string | null) => void;
}): React.ReactNode;
//# sourceMappingURL=ContextBarView.d.ts.map