import React from 'react';
import type { JobRow } from '../../dsh-adapter/channel.js';
/**
 * Live background-job card embedded in the transcript (`kind: 'job'`),
 * sibling of the subagent card: header (id · kind · label · elapsed ·
 * status) plus a bounded output waterfall (up to three rows) while the job
 * is live — and only when mirrored output exists: background jobs are
 * usually silent, so an outputless card is just its header line, never a
 * row of empty gutters. Settled jobs fold to the header line alone (a
 * failed/killed job keeps one detail line); the `/jobs` panel holds the
 * fuller view the card clicks to.
 *
 * The waterfall is MIRRORED, never polled: the harness job registry's read
 * is consuming and reserved for the owning agent, so the card shows the
 * tail of the agent's own job_output results as they stream through the
 * transcript.
 */
export declare function JobCard({ job, marginTopOnTurn, onClick }: {
    job: JobRow;
    marginTopOnTurn: boolean;
    onClick?(): void;
}): React.ReactNode;
//# sourceMappingURL=JobCard.d.ts.map