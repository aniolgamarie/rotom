/**
 * The approval panel — permission prompt for the DSH
 * approval seam (`ctx.approval`). One ask per panel: a permission-colored
 * divider header naming the tool, the gated command recovered from the
 * paired tool call, the asker's reason,
 * "Allow this operation?", and a numbered Yes/No list.
 *
 * The protocol's outcome set is closed (allowed-once / rejected /
 * cancelled / unavailable) with no allow-always or feedback channel, so
 * the panel deliberately offers exactly two rows; Esc and Ctrl+C reject
 * (fail closed; Esc cancels the request).
 */
import React from 'react';
import type { ApprovalSnapshot } from '../../dsh-adapter/approvals.js';
export type ApprovalPanelProps = {
    /** The approval to render (from the ApprovalStore snapshot). */
    readonly approval: ApprovalSnapshot;
    /** True when the asking agent is NOT the attached session — a background
     *  (agent view) session's ask, answered from the same single panel. */
    readonly background?: boolean;
    readonly onDecide: (outcome: 'allowed-once' | 'rejected') => void;
};
export declare function ApprovalPanel({ approval, background, onDecide }: ApprovalPanelProps): React.ReactNode;
//# sourceMappingURL=ApprovalPanel.d.ts.map