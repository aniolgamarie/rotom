import React from 'react';
import type { PermissionPresetOption } from '../dsh-adapter/channel.js';
/**
 * `/permission` sandbox-preset picker. The command itself is registered by
 * the harness side (dsh-sandbox-policy / dsh-base permission-presets row);
 * bare `/permission` opens this picker and Enter dispatches
 * `/permission <preset>` through the same external-command path a hand-typed
 * argument takes. The roster comes from the adapter snapshot so host plugins
 * can contribute additional preset identities without UI changes.
 */
export declare function PermissionsPicker({ options, focusIndex, currentValue, cwd, onPick, }: {
    options: readonly PermissionPresetOption[];
    focusIndex: number;
    currentValue: string | undefined;
    cwd: string;
    /** Mouse pick (fullscreen): clicked row's absolute index (Chat applies
     *  the same code path as the keyboard Enter). */
    onPick?: (index: number) => void;
}): React.ReactNode;
//# sourceMappingURL=PermissionsPicker.d.ts.map