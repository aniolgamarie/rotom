/**
 * The questionnaire panel — ask-user-question UI for the
 * DSH user-interaction seam. One question per panel (progress header, header
 * chip, wrapped question text, optional detail, option list with focus
 * pointer and multi-select checkmarks), styled in the dsh-tui mist-blue
 * design language.
 *
 * The list's last row IS the free-text input (issue #9): no Tab, no mode
 * switch — the view never changes. Typing while focused on a real option
 * appends into that input row (single-select also attaches the option's
 * label, so the answer can carry both `selected` and `custom`); focusing
 * the input row itself and typing gives a pure custom answer.
 *
 * Paste works on the input row like the composer: Ctrl+V/Alt+V (the keymap
 * `paste` binding, remappable in /settings) reads the system clipboard,
 * and a terminal bracketed paste (Ctrl+Shift+V / right-click / terminals
 * that intercept Ctrl+V) inserts its chunk — newlines and control chars are
 * flattened to spaces, pasted content never submits the panel. Editing
 * state (value + caret) lives in refs mutated synchronously per event: a
 * terminal delivers one stdin chunk as several key events inside a single
 * React batch, and the clipboard read resolves asynchronously — state
 * queued by one event is invisible to the next, and a paste must land at
 * the caret the user actually sees. The caret counts CODE POINTS (`[...s]`
 * iteration, same contract as the plugin InputDialog), so an emoji can
 * never be split into a lone surrogate by ←/→/⌫/Del or a paste boundary.
 */
import React from 'react';
import type { QuestionDraft, QuestionSelection } from '../../dsh-adapter/questions.js';
import { type ClipboardRead } from '../../utils/clipboard.js';
export type AskUserQuestionPanelProps = {
    /** The question to render (from the QuestionStore snapshot). */
    readonly question: {
        readonly question: string;
        readonly header?: string;
        readonly detail?: string;
        readonly options?: ReadonlyArray<{
            readonly label: string;
            readonly description?: string;
        }>;
        readonly multiSelect?: boolean;
        /** Hide the trailing free-text input row for pure option questions
         *  (local wizards, e.g. /provider). Ignored when there are no options —
         *  a text-only question would otherwise be unanswerable. */
        readonly hideCustomInput?: boolean;
        /** Pre-checked option labels (multi-select) / default-focused option
         *  (single-select) shown on first display, before any saved draft — e.g.
         *  the models already enabled on a provider being edited. */
        readonly defaultSelected?: readonly string[];
        /** Presentation intent tag (rc.6): 'plan-review' switches to the
         *  decision-card layout; an intent never changes the protocol. */
        readonly intent?: {
            readonly kind: 'plan-review';
            readonly approve: string;
        };
    };
    /** 1-based position within the batch (progress header). */
    readonly position: number;
    /** Total questions in the batch (progress header). */
    readonly total: number;
    /** Questions answered before the current one. */
    readonly answered: number;
    /** Previously saved answer or draft, restored when returning to this item. */
    readonly initialDraft?: QuestionDraft;
    readonly onAnswer: (selection: QuestionSelection) => void;
    /** Esc on the first question / Ctrl+C — aborts the whole ask. */
    readonly onCancel: () => void;
    /** Esc on later questions — navigates to the previous question. */
    readonly onBack?: (draft: QuestionDraft) => void;
    /**
     * Test seam: clipboard reader for the Ctrl+V paste arm. Defaults to the
     * real cross-platform reader (PowerShell/pbpaste/wl-paste…); headless
     * verification injects a fake so paste outcomes are deterministic.
     */
    readonly readClipboardOverride?: () => Promise<ClipboardRead>;
};
export declare function AskUserQuestionPanel({ question, position, total, answered, initialDraft, onAnswer, onCancel, onBack, readClipboardOverride, }: AskUserQuestionPanelProps): React.ReactNode;
//# sourceMappingURL=AskUserQuestionPanel.d.ts.map