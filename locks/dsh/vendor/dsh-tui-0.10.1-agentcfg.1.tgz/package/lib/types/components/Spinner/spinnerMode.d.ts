export type { SpinnerMode } from '../../adapter/ports/channel-display.js';
//# sourceMappingURL=spinnerMode.d.ts.map