import React from 'react';
import { type ScrollBoxHandle } from '../ui.js';
/**
 * Proportional scrollbar for the fullscreen transcript's gutter — the
 * `scrollbar` option of the `dsh-tui.scrollGutter` setting (the timeline
 * rail's sibling; same 2-column slot, same chrome rules):
 *
 *  - the thumb (██) shows the visible window's position AND size over the
 *    whole content (viewport²/content tall, positioned by scrollTop);
 *  - clicking the track scrolls the clicked position to the viewport top
 *    (classic scrollbar semantics — the thumb centers under the click
 *    through the follow-up renders);
 *  - the gutter is permanent while scrollable (Qwen's rule: an
 *    auto-hiding gutter that changes content width rewraps everything);
 *    hidden below 60 terminal columns or when the content fits (inline
 *    mode keeps the terminal's native scrollback);
 *  - NoSelect fences the glyphs out of click-drag text selection; the
 *    wheel over the gutter scrolls the transcript.
 *
 * Thumb dragging is intentionally NOT implemented (Grok's MVP rule): a
 * proportional thumb encodes position, and the tick rail remains the
 * semantic navigator. Click-to-position covers the same need.
 */
export declare function ScrollbarGutter({ handle, terminalWidth, }: {
    handle: ScrollBoxHandle | null;
    terminalWidth: number;
}): React.ReactNode;
//# sourceMappingURL=ScrollbarGutter.d.ts.map