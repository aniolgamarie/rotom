/**
 * Persisted reasoning-effort preference (`~/.dsh-tui/effort.json`). Set via
 * `/effort` (slider or `/effort <id>`; `/effort status` reports the current
 * level) — note Shift+Tab cycles session modes (default/plan/full), not
 * effort levels. The choice lands here so the next boot starts on it. The
 * file is best-effort: a missing/corrupt file or a level the current adapter
 * does not offer just falls back to the provider default — the first
 * request/header event always re-asserts the truth on the status line.
 */
/**
 * The persisted reasoning-effort id, or undefined when unset or invalid.
 * @param dir - Prefs directory (injectable for tests).
 * @returns The persisted effort id, if any.
 */
export declare function readEffortPref(dir?: string): string | undefined;
/**
 * Default reasoning-effort precedence for sessions that do not carry their
 * own choice: the /settings 默认推理强度 user layer (`settings.yaml
 * dsh-tui.effortDefault`; the plugin folds the `auto` option to undefined
 * before calling), then the cordis.yml `effort` pin, then this persisted
 * `/effort` file, then the adapter/model default (undefined). Mirrors the
 * lang chain (settings user layer > cordis.yml > lang.json).
 * @param settingsDefault - settings user-layer level (undefined = auto).
 * @param configured - cordis.yml `effort` value, if any.
 * @param persisted - The /effort choice, if any.
 * @returns The winning level id, or undefined for the adapter default.
 */
export declare function resolveEffortDefault(settingsDefault: string | undefined, configured: string | undefined, persisted: string | undefined): string | undefined;
/**
 * Persist the chosen reasoning-effort id (best effort).
 * @param effort - Adapter-owned effort id to persist.
 * @param dir - Prefs directory (injectable for tests).
 * @returns True when the file was written, false on failure.
 */
export declare function writeEffortPref(effort: string, dir?: string): boolean;
//# sourceMappingURL=effortPrefs.d.ts.map