/**
 * Minimal mode: one process-wide flag gating decorative UI (header splash,
 * emoji status glyphs, non-tool text colors, status-bar extras). The flag is
 * owned by the channel (settings `dsh-tui.minimal`, applied live through
 * scope.watch); leaf components read it here instead of threading a prop
 * through four render layers. Code highlighting and tool-name colors are
 * deliberately NOT gated — minimal keeps those.
 */
/** True when minimal mode is active (settings `dsh-tui.minimal`). */
export declare function isMinimalMode(): boolean;
/** @internal channel-owned setter; also called once at boot. */
export declare function setMinimalMode(enabled: boolean): void;
//# sourceMappingURL=minimalMode.d.ts.map