import type { Context } from '@deepseek-ai/cordis';
import { type SessionModeSpec } from '../../sessionModes.js';
import type { createChannelBinding } from './binding.js';
import { createModeActions } from './mode-actions.js';
import { type PermissionIdentity } from './mode-permission.js';
import type { PermissionModeRoster } from './mode-roster.js';
import type { ChannelState } from './types.js';
type Binding = ReturnType<typeof createChannelBinding>;
type ModeState = Pick<ChannelState, 'mode' | 'modeIndex' | 'emit'>;
type ModeCapture = ReturnType<Binding['capture']>;
/** The composition seam `createModeActions` owns; this factory forwards every
 *  member verbatim so both stay in lockstep. */
type BaseModeActionDeps = Parameters<typeof createModeActions>[2];
/**
 * Permission-aware session-mode actions: main's mode transition (plan
 * exclusivity, atom application, plan-exit restore) composed with the durable
 * permission identity, on top of the refactored `createModeActions`.
 *
 * Construction is inert. The returned shape is a superset of
 * `ReturnType<typeof createModeActions>`, so the composition root and
 * `createBindingEvents` can consume it unchanged, plus
 * `runPermissionPreset` for the public `ChannelUi` surface.
 */
export declare function createPermissionModeActions(ctx: Context, state: ModeState, deps: Pick<BaseModeActionDeps, 'owner' | 'runtime' | 'binding' | 'sessionModes' | 'commandService' | 'executeRegistryCommand' | 'notify'> & {
    roster: PermissionModeRoster;
}): {
    refreshMode(): void;
    cycleMode(): Promise<void>;
    applyMode(spec: SessionModeSpec, capture?: ModeCapture): Promise<void>;
    onSessionEvent(session: unknown, event: unknown): void;
    runPermissionPreset(name: string): Promise<boolean>;
    permission: PermissionIdentity;
};
export {};
//# sourceMappingURL=mode-permission-actions.d.ts.map