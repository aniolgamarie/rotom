import type { BackgroundJobStatus, BackgroundJobState } from '../adapter/ports/channel-view.js';
export type { BackgroundJobStatus, BackgroundJobState } from '../adapter/ports/channel-view.js';
/**
 * Structural mirror of the registry's `JobSnapshot` — only the fields the
 * UI reads. Declared locally so no `@deepseek-ai/dsh-jobs` dependency (peer
 * range churn) is introduced; the harness service satisfies this shape.
 */
export interface BackgroundJobSnapshot {
    /** Registry-issued id (`<kind>-N`, e.g. `pwsh-3`). */
    id: string;
    /** Producer kind (`bash`, `pwsh`, `subagent`, `pty-send`, …). */
    kind: string;
    /** One-line label — the command or delegation description. */
    label: string;
    status: BackgroundJobStatus;
    /** Kind-specific status detail, usually terminal ('exit code: 0'). */
    detail?: string;
    /** Epoch ms when the job was registered. */
    startedAt: number;
    /** Epoch ms when the job settled; absent while running/stopping. */
    finishedAt?: number;
}
/**
 * Duck-typed registry surface the channel consumes. `caller` is the owning
 * live agent (`Agent` in the harness) — typed as object here because the
 * UI only forwards the instance it already holds.
 */
export interface JobsRuntime {
    /** Caller-owned + unowned job snapshots in registration order. */
    list(caller?: object): BackgroundJobSnapshot[];
    /** Request cancellation by id; resolves to 'requested'/'already-finished'. */
    kill(id: string, caller?: object, reason?: string): unknown;
    /** Fires after every commit changing one owner's visible set; re-read. */
    onJobsChanged?(listener: (owner: unknown) => void): () => void;
    /** Fires on every settlement with the terminal snapshot + owner. */
    onJobDone?(listener: (snapshot: BackgroundJobSnapshot, owner: unknown) => void): () => void;
}
/** Store event hooks the channel injects (toast on settle, emit on change). */
export interface BackgroundJobEvents {
    /** A job the store knew live just settled (or vanished mid-flight). */
    onSettled?(job: BackgroundJobState): void;
    /** The visible set changed; the channel syncs rows and emits. */
    onChanged?(): void;
}
/** Total tracked jobs kept (running plus most recent terminal ones). */
export declare const JOBS_MAX_TRACKED = 40;
/** Output tail lines retained per job (the card waterfall shows the last 3;
 *  the /jobs panel detail shows the whole retained tail). */
export declare const JOBS_MAX_OUTPUT_LINES = 30;
/**
 * Ordered store of the current conversation's background jobs. Fed by
 * {@link BackgroundJobStore.replace} with a fresh `list()` after every
 * `onJobsChanged` commit, and by {@link BackgroundJobStore.onOutputSeen}
 * with the tail of every `job_output` tool result. Emits no React state of
 * its own — the channel wires the events into its version bump, exactly
 * like the subagent projection.
 */
export declare class BackgroundJobStore {
    private readonly events;
    private readonly jobs;
    /** Commands captured from start acks that arrived before the registry
     *  registered the job (the tool/result stream and the registry commit can
     *  race); consumed on registration. */
    private readonly pendingCommands;
    constructor(events?: BackgroundJobEvents);
    /**
     * Diff a fresh `list()` against the tracked set: register new jobs, fold
     * status/detail transitions, and fire `onSettled` for live→terminal moves.
     * Jobs that vanish while live were teardown-cancelled (session swap /
     * owner disposal) and are frozen as `killed` and KEPT as recent history —
     * their transcript rows freeze at a sensible terminal state instead of
     * ticking on, and the panel keeps them alongside other finished work
     * (the tracked bound below trims the oldest terminals).
     */
    replace(snapshots: readonly BackgroundJobSnapshot[]): void;
    /**
     * Record the full command that started a job, captured from its tool
     * call's args via the `started background job <id>` ack. May arrive
     * before the registry registers the job — the command is parked and
     * consumed by the next replace().
     */
    onStarted(id: string, command: string): void;
    /**
     * Mirror the tail of a `job_output` tool result for one job. Appends
     * non-empty lines (excluding the tool's `[status: …]` suffix) and keeps
     * the bounded tail. This is the ONLY output feed — the registry's read is
     * consuming and reserved for the owning agent.
     * @param at - wall-clock receipt time of the read (defaults to now).
     */
    onOutputSeen(id: string, text: string, at?: number): void;
    /** A fresh snapshot in registration order (newest tracked job last). */
    snapshot(): readonly BackgroundJobState[];
    get(id: string): BackgroundJobState | undefined;
    /** Jobs still alive (running or being stopped). */
    runningCount(): number;
    /** Drop everything (session swap / transcript wipe). */
    reset(): void;
}
/** `3s` under a minute, `3m12s` under an hour, `1h02m` beyond — transcript-card compact. */
export declare function formatJobDuration(job: Pick<BackgroundJobState, 'startedAt' | 'finishedAt'>, now?: number): string;
//# sourceMappingURL=jobs.d.ts.map