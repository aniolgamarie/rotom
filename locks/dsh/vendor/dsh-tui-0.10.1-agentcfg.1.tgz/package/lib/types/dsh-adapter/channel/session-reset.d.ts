import type { ChannelState } from './types.js';
export type SessionResetState = Pick<ChannelState, 'rows' | 'todos' | 'pending' | 'goal' | 'sessionTitle' | 'sessionColor' | 'tokens' | 'responseChars' | 'activeToolCount' | 'lastUserText' | 'working' | 'cancelPending' | 'spinnerMode' | 'tps' | 'tpsSamples' | 'lastUsage' | 'workingActivity' | 'contextSegments'>;
/**
 * Reset the projection facts shared by every foreground session adoption.
 * Target-specific route, cwd, preset, loaded-context and status fields stay
 * with the caller: not every adoption has the same semantics for those.
 */
export declare function resetSessionProjection(state: SessionResetState, rowIds: {
    value: number;
}, resetProjector: () => void, resetSubagents: () => void, resetJobs: () => void): void;
//# sourceMappingURL=session-reset.d.ts.map