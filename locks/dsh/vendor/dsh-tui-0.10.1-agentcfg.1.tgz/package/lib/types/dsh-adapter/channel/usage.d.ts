import { type StreamChunk } from '@deepseek-ai/dsh-llm';
import type { TokenUsage } from './types.js';
/** 全零 token 累计（新会话 / 复位用）。 */
export declare function emptyTokenUsage(): TokenUsage;
/** Context-bar token estimate (pi-nano-context: ~4 chars per token). */
export declare function estimateTokens(text: string): number;
/** Whether one stream chunk advances the first-token/decode boundary. */
export declare function isTokenDelta(chunk: StreamChunk): boolean;
/** Character payload of one token-bearing stream delta for the live fallback. */
export declare function tokenDeltaChars(chunk: StreamChunk): number;
/** Provider output count when usable; durable imports may predate strict validation. */
export declare function usageOutputTokens(usage: unknown): number | undefined;
//# sourceMappingURL=usage.d.ts.map