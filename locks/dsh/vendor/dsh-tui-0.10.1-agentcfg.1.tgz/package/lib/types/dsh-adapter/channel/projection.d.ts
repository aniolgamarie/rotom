import type { Agent, AssistantStreamFrame } from '@deepseek-ai/dsh-agent';
import type { SessionEvent } from '@deepseek-ai/dsh-session';
import type { ContentBlock } from '@deepseek-ai/dsh-llm';
import type { ChannelState, ToolCallView, ToolResultView, ToolsRegistryLike } from './types.js';
import type { InputConvergence } from './input-actions.js';
import type { BackgroundJobStore } from '../jobs.js';
import type { TuiRendererHost } from '../renderers.js';
type ProjectionState = Pick<ChannelState, 'rows' | 'thinkingFold' | 'activeToolCount' | 'spinnerMode' | 'goal' | 'contextSegments' | 'tokens' | 'lastUsage' | 'lastUserText' | 'responseChars' | 'tps' | 'cancelPending' | 'working' | 'turnStart' | 'tpsSamples' | 'contextWindow' | 'reasoningEffort' | 'sessionTitle' | 'todos' | 'agentPreset' | 'sessionColor' | 'status' | 'emit'>;
interface ProjectionDependencies {
    agent(): Agent;
    rowIds: {
        value: number;
    };
    resetContextWarning(): void;
    pendingTaskDescriptions: string[];
    jobs: Pick<BackgroundJobStore, 'onOutputSeen' | 'onStarted'>;
    inputConvergence: Pick<InputConvergence, 'cancelInFlight'>;
    checkContextWarning(): void;
    notify: ChannelState['notify'];
    tools?: ToolsRegistryLike;
    renderer?: TuiRendererHost;
    /** DSH attachment service, resolved at call time (a late-mounted provider
     *  must still serve images for rows projected earlier). */
    attachments(): unknown;
}
/** One authoritative reducer for both durable replay and live session events. */
export declare function createChannelProjection(state: ProjectionState, deps: ProjectionDependencies): {
    reset: () => void;
    replayEvents: (events: readonly SessionEvent[]) => void;
    renderEvent: (event: SessionEvent) => void;
    renderStreamFrame: (frame: AssistantStreamFrame) => void;
    settleStreaming: () => void;
    updateSpinnerMode: () => void;
    presentCallView: (name: string, rawArgs: string) => ToolCallView | undefined;
    presentResultView: (name: string, rawArgs: string, data: SessionEvent<"tool/result">["data"]) => ToolResultView | undefined;
    textOf: (content: readonly ContentBlock[] | undefined) => string;
    firstTextOf: (content: readonly ContentBlock[] | undefined) => string;
};
export {};
//# sourceMappingURL=projection.d.ts.map