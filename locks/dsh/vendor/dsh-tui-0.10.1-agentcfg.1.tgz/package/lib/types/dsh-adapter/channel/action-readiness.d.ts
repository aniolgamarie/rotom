import type { ChannelState } from './types.js';
/**
 * The Channel installs its effectful command delegates atomically after every
 * specialist has been constructed.  Construction-time callers fail closed
 * rather than receiving a plausible no-op while the Channel is incomplete.
 */
export type ChannelActionDelegates = Pick<ChannelState, 'commandCompletions' | 'loadOlder' | 'rewindTo' | 'rewindToNode' | 'forkSession' | 'resumeTo' | 'newSession' | 'listWorkspaces' | 'resolveWorkspace' | 'switchWorkspace' | 'renameWorkspace' | 'workspaceCommands' | 'runWorkspaceCommand' | 'switchModel' | 'listEfforts' | 'setEffort' | 'setDefaultEffort' | 'cycleMode' | 'runPermissionPreset' | 'clear' | 'setActivityFrames' | 'listPresets' | 'switchPreset' | 'listModels' | 'listProviders' | 'invalidateModelCompletion' | 'listSkills' | 'describeCredential' | 'balanceInfo' | 'sideQuestion' | 'listFileCandidates' | 'listFiles' | 'listSessions' | 'previewSession' | 'bindApprovalStore' | 'agentViewRows' | 'subscribeAgentView' | 'dispatchBackgroundAgent' | 'stopBackgroundAgent' | 'attachToAgent' | 'peekAgentSession' | 'replyToAgent' | 'backgroundCurrent' | 'setResumeTarget' | 'renameSession' | 'setSessionColor' | 'recapRecent' | 'deleteSession' | 'renameSessionTo' | 'compact' | 'runExternalCommand' | 'runExternalCommandOutcome' | 'pushLocal' | 'mcpStatus' | 'exportSession' | 'initWorkspace' | 'doctorInfo' | 'pluginsInfo' | 'listSubagents'> & {
    runLocalCommand(command: string, includeInContext: boolean): Promise<void>;
};
type ChannelActionMethodName = Exclude<keyof ChannelActionDelegates, 'runLocalCommand'>;
export type ChannelActionMethods = Pick<ChannelState, ChannelActionMethodName>;
/** The ChannelState-facing half of the readiness cell is deliberately pure:
 * one typed forwarding method per public action, with no service access. */
export declare function createChannelActionMethods(getReadyActions: () => ChannelActionDelegates): ChannelActionMethods;
export declare function createChannelActionReadiness(): {
    install(next: ChannelActionDelegates): void;
    getReadyActions(): ChannelActionDelegates;
};
export {};
//# sourceMappingURL=action-readiness.d.ts.map