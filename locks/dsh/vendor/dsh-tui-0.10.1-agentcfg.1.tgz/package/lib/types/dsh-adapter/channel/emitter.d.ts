import type { ChannelState } from './types.js';
export declare function createChannelEmitter(getState: () => Pick<ChannelState, 'rows' | 'version'>, 
/** Returns true when the deferred projector changed renderer-visible data. */
beforeStream: () => boolean): {
    subscribe(listener: () => void): () => void;
    emit(): void;
    emitStream(): void;
    dispose(): void;
};
//# sourceMappingURL=emitter.d.ts.map