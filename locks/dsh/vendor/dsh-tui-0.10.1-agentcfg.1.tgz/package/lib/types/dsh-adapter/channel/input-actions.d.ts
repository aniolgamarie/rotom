/** Input actions own cancellation/requeue convergence, not session binding. */
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { ChannelState, ComposerImageRef } from './types.js';
export interface InputConvergence {
    cancelInFlight: boolean;
    interruptSeq: number;
}
export declare function createInputActions(getState: () => Pick<ChannelState, 'agentId' | 'pending' | 'cancelPending' | 'emit' | 'notify'>, getAgent: () => Agent, owner: {
    assertActive(): void;
}, input: InputConvergence, composer: {
    includeLegacyImageRefs(text: string, images: readonly ComposerImageRef[]): readonly ComposerImageRef[];
}, dispatchUserText: (text: string, placement: 'steer' | 'followup', images?: readonly ComposerImageRef[]) => void, runLocalCommand: (command: string, includeInContext: boolean) => Promise<void>): Pick<ChannelState, 'submit' | 'steer' | 'removePending' | 'cancel' | 'interruptAndDeliver'>;
//# sourceMappingURL=input-actions.d.ts.map