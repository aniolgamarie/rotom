import type { Agent } from '@deepseek-ai/dsh-agent';
import type { Context } from '@deepseek-ai/cordis';
import { Config } from './index.js';
import { render } from '../ui.js';
/**
 * Extract the startup prompt from raw app argv. `--resume <session>` selects
 * a persisted session and must not leak its id into the conversation.
 */
export declare function initialPromptFromCmdlineArgs(args: readonly string[] | undefined): string;
/**
 * How this process should treat the TUI frontend, given the terminal it runs on.
 *
 * Three startup identities exist:
 *  1. `dsh-tui` / standalone — the user explicitly asked for the terminal UI;
 *  2. Web / Tauri / other GUI hosts — the profile merely has dsh-tui installed
 *     and the current process is NOT a dsh-tui frontend. stdout is a pipe or
 *     null there, and mounting a TUI would fail the whole composition.
 *
 * The official launcher (and the standalone runtime) mark explicit launches,
 * so an explicit `dsh-tui` run without a TTY keeps failing loudly, while
 * foreign hosts skip the plugin and let the host boot.
 */
export type TuiHostMode = 'interactive' | 'invalid-explicit-launch' | 'headless-host';
export declare function resolveTuiHostMode(stdoutIsTTY?: boolean, env?: NodeJS.ProcessEnv): TuiHostMode;
export declare function apply(ctx: Context, config: Config): Promise<void>;
/**
 * Distinguish a user-driven exit from a cordis context teardown (issue #12).
 *
 * Both paths settle the Ink instance's exit promise, but only a user exit
 * (`/exit`, double Ctrl+C, render crash) may leave the process. A teardown —
 * the DSH launcher's boot-time recompose disposes every entry once — must
 * only unmount the UI: the recomposed tree re-runs `apply` and mounts a
 * fresh instance, so exiting here would kill the process mid-recompose
 * (the "flash back to bash with no error" symptom).
 *
 * `markTeardown` must run before the unmount that settles the exit promise
 * (the settle reaches `handleExit` through a microtask, so a same-tick flag
 * is always observed). Exported for scripts/verify-teardown-exit.tsx.
 */
export declare function createExitFunnel(deps: {
    onUserExit: (error?: unknown) => void;
}): {
    handleExit: (error?: unknown) => void;
    markTeardown: () => void;
};
/**
 * Whether a user exit should leave the resume marker (and print the resume
 * hint). Must be judged against the LIVE session behind the channel, not the
 * boot-time agent apply() captured: /resume, /new and /model swap the active
 * agent (channel.agentId follows, the old handle is disposed), so the
 * captured reference can point at a stale session — wiping a marker the
 * resume path just wrote (boot empty → /resume into history) or rewriting it
 * to a fresh empty session (boot with history → /new). `liveAgent` is the
 * registry lookup of channel.agentId; it falls back to the captured agent
 * when the lookup misses. Exported for scripts/verify-exit-resume-marker.
 */
export declare function isExitResumable(deps: {
    pendingCount: number;
    liveAgent: Agent | undefined;
    startupAgent: Agent;
}): boolean;
/**
 * Finish terminal I/O before handing control to a process-level exit action.
 * Exported for scripts/verify-shutdown-fallback.
 */
export declare function finishExit(ctx: Context, instance: Awaited<ReturnType<typeof render>> | undefined, fullscreen: boolean, notice: string | undefined, stderrNotice: string | undefined, done: () => void): Promise<void>;
//# sourceMappingURL=plugin.d.ts.map