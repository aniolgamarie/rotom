/**
 * /plugins diagnostics surface (C-070 trust disclosure + C-030 negotiation
 * diagnostics): assembles the lines behind the `/plugins` command.
 *
 * Sections (overview):
 *
 * 1. TRUST BANNER — always the first line (C-070): plugins run in-process;
 *    grants are behavioral constraints, not a security boundary; passing
 *    validation is not proof of safety.
 * 2. HOST DESCRIPTOR summary — what the running host actually advertises
 *    (coordinates + generation), including drift-dropped contracts.
 * 3. GRANT MATRIX — plugins × the registered permissions. The plugin set is
 *    the union of FOOTPRINTS ONLY: keys of the grants file, pluginIds seen
 *    in the effect ledger, and storage namespaces on disk (the host cannot
 *    enumerate installed plugins — that knowledge lives in the dsh CLI
 *    Loader). The header says so honestly.
 * 4. LEDGER TAIL — the last 5 effect-ledger records.
 *
 * `/plugins check <path>` uses the parser and projection from the pinned
 * @dsh-std/manifest revision, then evaluates every public/private protocol
 * through one ProtocolCatalog. Manifests and on-disk files are UNTRUSTED input:
 * every derived line passes cleanScalarText before it reaches the
 * transcript.
 */
import type { GrantStore } from '../adapter/standard/grants.js';
import type { HostDescriptorBuild } from '../adapter/standard/descriptor.js';
/** How many plugins the matrix shows before an overflow note. */
export declare const PLUGINS_MATRIX_MAX_ROWS = 20;
/** How many ledger records the tail section shows. */
export declare const PLUGINS_LEDGER_TAIL = 5;
export interface PluginsInfoDeps {
    /** Effective grant answers (the plugin-host row's store when mounted). */
    grants: GrantStore;
    /** The plugin-host row's descriptor build; undefined → row not mounted. */
    host?: HostDescriptorBuild;
    /** Test overrides; default under DATA_DIR. */
    dataDir?: string;
    ledgerFile?: string;
    storageDir?: string;
}
/** The `/plugins` overview lines (banner always first). */
export declare function pluginsInfoLines(args: string, deps: PluginsInfoDeps): string[];
//# sourceMappingURL=plugins-info.d.ts.map