import type { AgentHandle } from '@deepseek-ai/dsh-agent';
import type { Context } from '@deepseek-ai/cordis';
import { type SessionEvent } from '@deepseek-ai/dsh-session';
import { resetSessionProjection } from './session-reset.js';
import type { createChannelBinding } from './binding.js';
import type { ChannelOwner } from './owner.js';
import { type AdapterRuntimeOptions } from '../../adapter/kernel/runtime.js';
import type { ChannelState, ResumeResult } from './types.js';
type Binding = ReturnType<typeof createChannelBinding>;
type ResumeState = Pick<ChannelState, 'working' | 'status' | 'agentId' | 'cwd' | 'displayCwd' | 'agentPreset' | 'provider' | 'model' | 'loadedContext' | 'contextWindow' | 'effortLevels' | 'reasoningEffort' | 'working' | 'emit'> & Parameters<typeof resetSessionProjection>[0];
export type NewSessionTarget = {
    /** Internal guarded workspace handoff; never exposed on ChannelUi.newSession(). */
    readonly cwd: string;
    readonly displayCwd?: string;
};
/** Persisted-session and fresh-session foreground actions. */
export declare function createSessionResumeActions(ctx: Context, state: ResumeState, options: {
    configuredPreset?: string;
    configuredProvider?: string;
    configuredModel?: string;
    provider: string;
    model: string;
}, deps: {
    owner: Pick<ChannelOwner, 'current'>;
    binding: Pick<Binding, 'agent' | 'capture' | 'isCurrent' | 'prepare' | 'abandon' | 'adopt'>;
    backgroundHandles: Map<string, AgentHandle>;
    rowIds: {
        value: number;
    };
    resetProjector(): void;
    resetSubagents(): void;
    resetJobs(): void;
    replay(events: readonly SessionEvent[]): void;
    settleReplay(): void;
    describeWorkspace(cwd: string): {
        description?: string;
    };
    refreshGitBranch(): void;
    bindAgent(): void;
    refreshCommands(): void;
    refreshLoadedContext(): Promise<void>;
    refreshSkillCommands(): Promise<void>;
    clearStagedImages(): void;
    settleCompaction(): Promise<void>;
    sessionSwitchVetoed(kind: 'new' | 'resume' | 'agent-view', targetSessionId?: string): Promise<boolean>;
    notify: ChannelState['notify'];
    notifySessionSwitched(kind: 'new' | 'resume' | 'agent-view', sessionId: string, previousSessionId: string): void;
    runtime: AdapterRuntimeOptions;
}): {
    resumeInto: (sessionId: string, kind: "resume" | "agent-view", keepCurrent: boolean) => Promise<ResumeResult>;
    resumeTo: (sessionId: string) => Promise<ResumeResult>;
    newSession: () => Promise<boolean>;
    newSessionWithTarget: (target?: NewSessionTarget) => Promise<boolean>;
};
export {};
//# sourceMappingURL=session-resume.d.ts.map