import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { CommandRuntime } from '@deepseek-ai/dsh-commands';
import { type LocalCommand, type LocalizedDescriptions } from '../../commands.js';
import type { ChannelOwner } from './owner.js';
import type { SkillRegistry } from './loaded-context.js';
/** Owns the merged catalog, host registrations, retry timer and all skill reads. */
export declare function createSkillCatalog(ctx: Context, deps: {
    owner: Pick<ChannelOwner, 'current' | 'own'>;
    commandService: CommandRuntime | undefined;
    agent(): Agent;
    cwd(): string;
    setCommands(commands: LocalCommand[]): void;
    commandDescriptions(name: string): LocalizedDescriptions | undefined;
    deliverUserText(text: string, placement: 'followup'): void;
}): {
    start: () => void;
    release: () => void;
    refreshCommands: () => void;
    refreshSkillCommands: () => Promise<void>;
    registryFor: (agent: Agent) => SkillRegistry | undefined;
    viewOptions: (agent: Agent) => {
        scope: Agent;
        cwd: string;
    };
};
//# sourceMappingURL=skill-catalog.d.ts.map