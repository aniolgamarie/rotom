import type { Context } from '@deepseek-ai/cordis';
import { type SessionEvent } from '@deepseek-ai/dsh-session';
import type { createChannelBinding } from './binding.js';
import type { ChannelOwner } from './owner.js';
import { resetSessionProjection } from './session-reset.js';
import type { ChannelState } from './types.js';
type Binding = ReturnType<typeof createChannelBinding>;
type SwitchState = Parameters<typeof resetSessionProjection>[0] & Pick<ChannelState, 'cwd' | 'working' | 'status' | 'agentId' | 'agentPreset' | 'provider' | 'model' | 'contextWindow' | 'effortLevels' | 'reasoningEffort' | 'emit'>;
/** Model-route adoption transaction. It settles compaction before its fork snapshot and owns the post-commit reset. */
export declare function createModelSwitchAction(ctx: Context, state: SwitchState, deps: {
    owner: Pick<ChannelOwner, 'current'>;
    binding: Pick<Binding, 'agent' | 'capture' | 'prepare' | 'isCurrent' | 'abandon' | 'adopt'>;
    rowIds: {
        value: number;
    };
    settleCompaction(): Promise<void>;
    resetProjector(): void;
    resetSubagents(): void;
    resetJobs(): void;
    replay(events: readonly SessionEvent[]): void;
    settleReplay(): void;
    bindAgent(): void;
    refreshCommands(): void;
    refreshLoadedContext(): Promise<void>;
    refreshSkillCommands(): Promise<void>;
    clearStagedImages(): void;
    dropModelCompletion(): void;
    onModelSwitch(model: string): void;
    notify: ChannelState['notify'];
}): (provider: string, model: string) => Promise<boolean>;
export {};
//# sourceMappingURL=model-switch.d.ts.map