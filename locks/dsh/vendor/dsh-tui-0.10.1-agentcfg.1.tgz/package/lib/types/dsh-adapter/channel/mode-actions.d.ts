import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { SessionEvent } from '@deepseek-ai/dsh-session';
import { type SessionModeSpec } from '../../sessionModes.js';
import { type AdapterRuntimeOptions } from '../../adapter/kernel/runtime.js';
import type { ChannelState } from './types.js';
import type { createChannelBinding } from './binding.js';
type Binding = ReturnType<typeof createChannelBinding>;
type ModeState = Pick<ChannelState, 'mode' | 'modeIndex' | 'emit'>;
/** Durable session-mode folds and transitions. Construction is inert; root wires it after state construction. */
export declare function createModeActions(ctx: Context, state: ModeState, deps: {
    owner: {
        current(): boolean;
    };
    runtime: AdapterRuntimeOptions;
    binding: Pick<Binding, 'agent' | 'capture' | 'isCurrent'>;
    sessionModes: readonly SessionModeSpec[];
    commandService?: {
        find(agent: Agent, name: string): unknown;
    };
    executeRegistryCommand(name: string, input: string): Promise<string | undefined>;
    notify: ChannelState['notify'];
}): {
    refreshMode: () => void;
    cycleMode: () => Promise<void>;
    applyMode: (spec: SessionModeSpec, capture?: import("./binding.js").BindingCapture) => Promise<void>;
    onSessionEvent: (session: Agent["session"], event: SessionEvent) => void;
};
export {};
//# sourceMappingURL=mode-actions.d.ts.map