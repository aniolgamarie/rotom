import type { AssistantStreamFrame, ModelSelectionRef } from '@deepseek-ai/dsh-agent';
import type { Context } from '@deepseek-ai/cordis';
import type { InputConvergence } from './input-actions.js';
import type { ChannelBinding } from './binding.js';
import type { ChannelOwner } from './owner.js';
import { type createChannelProjection } from './projection.js';
import type { ChannelState } from './types.js';
/**
 * The binding event router is the sole subscriber for a foreground Agent.
 * It captures the binding generation at every listener entry; teardown is
 * incremental and retained callbacks check that captured Agent/session pair
 * before touching state. Transcript presentation remains exclusively owned by
 * ChannelProjection.
 */
export declare function createBindingEvents(ctx: Context, deps: {
    owner: ChannelOwner;
    binding: ChannelBinding;
    state: ChannelState;
    activity: {
        start(agent: ChannelBinding['agent']): void;
        stop(): void;
        onAgentStatus(status: ChannelBinding['agent']['status']): unknown;
        onSessionEvent(event: unknown): unknown;
    };
    inputConvergence: InputConvergence;
    selection: ModelSelectionRef;
    modelActions: {
        applyPreferredEffort(): Promise<void>;
        selection: ModelSelectionRef;
    };
    modeActions: {
        refreshMode(): void;
        onSessionEvent(session: unknown, event: unknown): void;
    };
    projector: ReturnType<typeof createChannelProjection>;
    subagents: {
        onSessionEvent(session: unknown, event: unknown): boolean;
        onStreamFrame?(agent: unknown, frame: AssistantStreamFrame): boolean;
        onStart(info: {
            id: string;
            runId?: string;
            provider: string;
            local?: boolean;
        }): void;
        onEnd(info: {
            id: string;
            stopReason: string;
            lastAssistantMessage?: unknown[];
        }): void;
    };
    agentView: {
        schedule(): void;
    };
    messageObserver?: {
        publish(session: unknown, event: unknown): void;
    };
}): {
    bind: () => void;
};
//# sourceMappingURL=binding-events.d.ts.map