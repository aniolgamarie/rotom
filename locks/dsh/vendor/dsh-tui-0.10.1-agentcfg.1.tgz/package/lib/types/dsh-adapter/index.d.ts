/**
 * dsh-tui plugin entry. The TUI implementation lives in `./plugin.tsx` (its
 * render path is JSX); this module owns the plugin surface (`name`/`inject`/
 * `Config`/`apply`) at the package entry module and delegates
 * `apply` through a dynamic import so entry-scanning tooling and the Loader
 * resolve a plain `.ts` module.
 * @module @deepseek-harness-tui/dsh-tui
 */
import type { Context } from '@deepseek-ai/cordis';
import Schema from '@deepseek-ai/schemastery';
import type { SessionModeSpec } from '../sessionModes.js';
import { type PageMarginSetting, type ScrollGutterMode, type StatusBarConfig, type ToolBackground } from '../tuiDisplayPrefs.js';
import { type ShortcutActionId } from '../utils/keymap.js';
export declare const name = "dsh-tui";
export declare const inject: string[];
/**
 * dsh-tui plugin configuration: session attachment, model route, working
 * directory, and display preferences.
 */
export interface Config {
    /** Existing session to attach; a fresh session is created when absent. */
    sessionId?: string;
    /** LLM provider route. The route resolves atomically (issue #67): when
     *  cordis.yml names BOTH `provider` and `model`, that pair wins; otherwise
     *  the `/model` choice persisted in `~/.dsh-tui/model.json` wins whole;
     *  otherwise `agentDefaultModel` supplies the provider-neutral Harness
     *  default. A bare embedder without that service falls back to DeepSeek.
     *  A provider-only pin never half-overrides the persisted choice. */
    provider?: string;
    /** Model override passed to the agent; resolved together with `provider`
     *  as one atomic route (see `provider`). */
    model?: string;
    /** Session working directory. When absent, the git worktree root
     *  containing the invoking directory wins (the invoking directory itself
     *  outside any worktree) — never a bare launch subdirectory (issue #96). */
    cwd?: string;
    /** Absolute local path, file URL, or provider URI resolved before the
     *  initial agent is created. */
    workspace?: string;
    /** Reasoning effort applied to every request, validated against the live
     *  route's adapter levels (an unlisted level is ignored and the adapter
     *  default applies). Wins over the persisted /effort choice; also seeds
     *  the startup status line until the first request header reports the
     *  live value. */
    effort?: string;
    /** Show the live working line derived in-process from base session events. */
    activity?: boolean;
    /** Working-activity indicator preset (`moon8`/`moon`/`comet`/`dots`/…
     *  or `random`; see activityFrames.ts). When absent, the `/activity`
     *  choice persisted in `~/.dsh-tui/working-activity.json` wins, then the
     *  `moon8` default. */
    activityFrames?: string;
    /** Show the segmented context bar (the band under the input with the
     *  `ctx used/window` readout) in the status footer; off hides that row
     *  while the status/mode lines stay (issue #29). */
    contextBar?: boolean;
    /** Run in the terminal's alternate screen (full-screen terminal layout).
     *  Defaults to true — the fullscreen surface is the more complete one
     *  (mouse, timeline rail, scrollbar gutter, selection copy), so fresh
     *  installs start there; cordis.yml `fullscreen: false` or a /settings
     *  toggle opts back into the inline main-screen layout. */
    fullscreen?: boolean;
    /** Allow terminal image previews when supported (default true). Saved
     *  /settings choices override this value after restart. The environment
     *  override DSH_TUI_DISABLE_TERMINAL_IMAGES can always force previews off. */
    terminalImages?: boolean;
    /** UI language: `en` / `zh`. When absent, the `DSH_TUI_LANG` env var wins,
     *  then the `/lang` choice persisted in `~/.dsh-tui/lang.json`, then `zh`. */
    lang?: string;
    /** Agent preset id new sessions compose from (standard/ptc/minimal/
     *  cordis/… when the roster is mounted). When absent, the `/preset` choice
     *  persisted in `~/.dsh-tui/agent-preset.json` wins, then the roster
     *  default (`standard`). */
    preset?: string;
    /** Edit/Write diff presentation: `auto` picks side-by-side on wide
     *  terminals (≥110 cols) and unified below; `split`/`unified` force one
     *  layout. Editable live from the `/settings` screen. */
    diffLayout?: 'auto' | 'split' | 'unified';
    /** Thinking-block display: `preview` (default) streams a 2-3 line live
     *  preview and folds each step when it settles; `full` keeps thinking
     *  expanded until the whole turn ends. Editable live from `/settings`. */
    thinkingFold?: 'preview' | 'full';
    /** Tool-card background strength; defaults to no added background. */
    toolBackground?: ToolBackground;
    /** What the fullscreen transcript's right gutter shows (settings
     *  `dsh-tui.scrollGutter`): `timeline` turn rail (default), `scrollbar`
     *  proportional thumb, or `hidden`. */
    scrollGutter?: ScrollGutterMode;
    /** Root page inset (settings `dsh-tui.pageMargin`): a preset name
     *  (`none` / `slim` / `normal` (default) / `roomy`) or a custom `NxM`
     *  spec (columns per side × rows top/bottom) that insets the whole UI
     *  from the terminal edges. Terminals without their own viewport padding
     *  (bare WSL, tmux, SSH) otherwise hug the screen border. */
    pageMargin?: PageMarginSetting;
    /** Terminal-card header folding (settings `dsh-tui.foldTerminalCommand`):
     *  `true` collapses a multi-line command title to its first line plus a
     *  `+N lines` hint; Ctrl+O / clicking the card expands it. Default off —
     *  the full title keeps rendering. */
    foldTerminalCommand?: boolean;
    /** Show the session name as a chip on the prompt top border's right side
     *  (settings `dsh-tui.promptSessionLabel`); off by default. */
    promptSessionLabel?: boolean;
    /** Fullscreen draft editor (settings `dsh-tui.expandEditor`): the ⛶
     *  affordance in the input row and the expandEditor shortcut (default
     *  Ctrl+Shift+E) expand the draft into a whole-screen editor. On by
     *  default; off removes both entry points. */
    expandEditor?: boolean;
    /** Smooth streaming reveal (settings `dsh-tui.smoothStreaming`): live
     *  assistant text, expanded thinking, and tool call bodies paint through
     *  a ~30fps reveal instead of jumping per provider burst — bursty or
     *  one-shot deliveries read as an even flow. On by default. */
    smoothStreaming?: boolean;
    /** Status-footer field visibility and compact presentation preferences. */
    statusBar?: Partial<StatusBarConfig>;
    /** Built-in action-shortcut overrides (`paste: 'alt+v'`), keyed by action
     *  id (see the keymap utility). Combos are `ctrl+`/`alt+`/`shift+` plus a
     *  key; several combos may be comma-separated. Unset actions keep their
     *  defaults; the `/settings` screen edits the same keys live (its user
     *  layer wins over this file). */
    shortcuts?: Partial<Record<ShortcutActionId, string>>;
    /** Shift+Tab session-mode cycle (array order IS the cycle order; index 0
     *  is the unmarked base mode). Each entry bundles any subset of the
     *  `plan`/`sandbox`/`approval` atoms; absent → the built-in
     *  default/plan/full cycle (see sessionModes.ts). */
    modes?: SessionModeSpec[];
}
export declare const Config: Schema<Config>;
/**
 * Start the interactive TUI front door, delegating to the JSX implementation
 * in `./plugin.tsx` (see its module doc for the full contract).
 * @param ctx - the plugin context.
 * @param config - the validated dsh-tui configuration.
 * @returns a promise settling when the TUI teardown completes.
 */
export declare function apply(ctx: Context, config: Config): Promise<void>;
//# sourceMappingURL=index.d.ts.map