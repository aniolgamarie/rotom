import type { TuiWorkspaceTarget, TuiWorkspaceCommand, TuiWorkspaceCommandResult } from '../adapter/ports/channel-workspace.js';
export type { TuiWorkspaceTarget, TuiWorkspaceKind, TuiWorkspaceCommand, TuiWorkspaceCommandResult, TuiWorkspaceChoice } from '../adapter/ports/channel-workspace.js';
import { Context, Service } from '@deepseek-ai/cordis';
export interface TuiCommandShell {
    resolve(request: {
        command: string;
        workdir?: string;
        timeoutMs?: number;
    }): unknown;
    run(spec: unknown): Promise<{
        exitCode: number | null;
        stdout: {
            text: string;
        };
        stderr: {
            text: string;
        };
        timedOut: boolean;
    }>;
}
export interface TuiWorkspaceProvider {
    /** URI schemes owned by this provider, without the trailing colon. */
    schemes: readonly string[];
    /** Enumerate targets owned by this provider. */
    list(signal?: AbortSignal): Promise<readonly TuiWorkspaceTarget[]> | readonly TuiWorkspaceTarget[];
    /** Resolve a provider URI, or return undefined when its scheme is not owned. */
    resolve(uri: string, signal?: AbortSignal): Promise<TuiWorkspaceTarget | undefined> | TuiWorkspaceTarget | undefined;
    /** Resolve a path relative to a cwd already owned by this provider. */
    resolvePath?(path: string, cwd: string, signal?: AbortSignal): Promise<TuiWorkspaceTarget | undefined> | TuiWorkspaceTarget | undefined;
    /** Describe an already-recorded cwd without performing I/O. */
    describe(cwd: string): TuiWorkspaceTarget | undefined;
    /** Override `!command` execution for a provider-owned cwd. */
    commandShell?(cwd: string): Promise<TuiCommandShell | undefined> | TuiCommandShell | undefined;
    /** Rename a provider-owned workspace durably. */
    rename?(cwd: string, title: string): Promise<TuiWorkspaceTarget | undefined> | TuiWorkspaceTarget | undefined;
    /** Provider-owned `/workspace <command>` extensions. */
    commands?: readonly TuiWorkspaceCommand[];
}
/** Host-only workspace controls used by the TUI front door.  Plugin-facing
 * service methods below are intentionally scoped to their calling activation;
 * the channel must use this facade to enumerate and route all providers. */
export interface TuiWorkspaceHost {
    list(currentCwd: string, signal?: AbortSignal): Promise<readonly TuiWorkspaceTarget[]>;
    resolve(request: string, currentCwd?: string, signal?: AbortSignal): Promise<TuiWorkspaceTarget | undefined>;
    describe(cwd: string): TuiWorkspaceTarget;
    commandShell(cwd: string): Promise<TuiCommandShell | undefined>;
    rename(cwd: string, title: string): Promise<TuiWorkspaceTarget>;
    commands(): readonly Pick<TuiWorkspaceCommand, 'name' | 'aliases' | 'description'>[];
    runCommand(name: string, input: string, cwd: string, signal?: AbortSignal): Promise<TuiWorkspaceCommandResult | undefined>;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        tuiWorkspaces: TuiWorkspaceRuntime;
    }
}
export declare const name = "dsh-tui-workspaces";
/** Bound every provider promise so one plugin cannot park workspace flows. */
export declare const WORKSPACE_PROVIDER_TIMEOUT_MS = 2000;
/** Registry and local fallback shared by the TUI and workspace plugins. */
export declare class TuiWorkspaceRuntime extends Service {
    constructor(ctx: Context);
    register(provider: TuiWorkspaceProvider): () => void;
    list(currentCwd: string, signal?: AbortSignal): Promise<readonly TuiWorkspaceTarget[]>;
    /** Resolve a URI, briefly allowing concurrently mounted providers to register. */
    resolve(reference: string, currentCwd?: string, signal?: AbortSignal): Promise<TuiWorkspaceTarget | undefined>;
    describe(cwd: string): TuiWorkspaceTarget;
    commandShell(cwd: string): Promise<TuiCommandShell | undefined>;
    rename(cwd: string, title: string): Promise<TuiWorkspaceTarget>;
    commands(): readonly Pick<TuiWorkspaceCommand, 'name' | 'aliases' | 'description'>[];
    runCommand(name: string, input: string, cwd: string, signal?: AbortSignal): Promise<TuiWorkspaceCommandResult | undefined>;
    private notifyProviderWaiters;
}
/** Resolve the host-only facade for channel/plugin bootstrap code. */
export declare function getHostWorkspaceRuntime(runtime: TuiWorkspaceRuntime | undefined): TuiWorkspaceHost | undefined;
/** Local-only fallback for direct embedders that call createChannel() without
 * mounting the optional workspace registry/provider service. */
export declare function createLocalWorkspaceRuntime(): Pick<TuiWorkspaceRuntime, 'list' | 'resolve' | 'describe' | 'commandShell' | 'rename' | 'commands' | 'runCommand'>;
export declare function localWorkspaceUri(path: string): string;
/** Resolve a native absolute path or the standard file URL form. */
export declare function parseLocalWorkspaceReference(reference: string): TuiWorkspaceTarget | undefined;
export default TuiWorkspaceRuntime;
//# sourceMappingURL=workspaces.d.ts.map