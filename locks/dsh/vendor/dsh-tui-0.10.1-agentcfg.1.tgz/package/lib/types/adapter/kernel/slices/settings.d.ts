import type { KernelSlice } from './types.js';
export declare const settingsSlice: KernelSlice;
//# sourceMappingURL=settings.d.ts.map