import type { KernelSlice } from './types.js';
export declare const scenesSlice: KernelSlice;
//# sourceMappingURL=scenes.d.ts.map