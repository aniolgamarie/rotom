import type { KernelSlice } from './types.js';
export declare const workspaceSlice: KernelSlice;
//# sourceMappingURL=workspace.d.ts.map