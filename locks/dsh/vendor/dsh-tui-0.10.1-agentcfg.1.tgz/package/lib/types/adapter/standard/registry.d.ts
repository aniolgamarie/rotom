/** Load and verify the pinned dsh-TUI admission profile. */
import type { ContractRegistry, PermissionRegistry, RegistryEntry } from './types.js';
export declare const DSH_STD_REVISION = "614dfa1ac168db79fcf4577cf0ebb34e2e3b944b";
export declare const ECOSYSTEM_SPEC_REVISION = "d28c267fe7fd775428ec2dccd65b0b7efd4dacee";
export interface SpecData {
    dir: string;
    registry: ContractRegistry;
    permissions: PermissionRegistry;
    schemas: {
        host: Record<string, unknown>;
        ledger: Record<string, unknown>;
        claim: Record<string, unknown>;
    };
}
export declare function locateSpecDir(start?: string): string | undefined;
export declare function loadSpecData(dir?: string | undefined): SpecData | undefined;
export declare function registryEntries(registry: ContractRegistry): RegistryEntry[];
export declare function digestFile(dir: string, relative: string): `sha256:${string}`;
/** Verify definition availability and private profile digest pins. */
export declare function verifyRegistry(data: SpecData): string[];
/** Verify the TUI-owned definitions; public definitions live in dsh-std. */
export declare function verifyContractProfiles(data: SpecData): string[];
//# sourceMappingURL=registry.d.ts.map