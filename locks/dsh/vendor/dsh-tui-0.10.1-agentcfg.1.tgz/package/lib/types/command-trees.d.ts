export { name, TuiCommandTreeRuntime } from './dsh-adapter/command-trees.js';
export type { TuiCommandTreeProvider } from './dsh-adapter/command-trees.js';
export { default } from './dsh-adapter/command-trees.js';
//# sourceMappingURL=command-trees.d.ts.map