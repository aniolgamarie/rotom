/**
 * dsh-plugin-oauth-subs host half.
 *
 * A Cordis plugin (export apply + inject + Config) that:
 *   1. runs a loopback OpenAI Responses proxy on 127.0.0.1:<port>
 *   2. drives ChatGPT Codex PKCE, xAI Grok device-code / PKCE,
 *      Zhipu GLM Z.ai / BigModel CLI-poll, AWS Kiro (Social / Builder ID /
 *      IdC / Entra / API key), Google Antigravity, Cursor, Ollama Cloud,
 *      Kimi Code Plan, and GitHub Copilot logins
 *   3. syncs logged-in catalogs into llm-pi-ai
 *
 * The client half (Settings > OAuth 订阅) is discovered from package.json
 * `dsh.client` — this module only owns the node process.
 */
import z from '@deepseek-ai/schemastery';
export declare const name = "dsh-plugin-oauth-subs";
export declare const inject: string[];
/** Schemastery Standard Schema — Cordis reads Config["~standard"].validate. */
export declare const Config: z<Schemastery.ObjectS<{
    port: z<number, number>;
    provider: z<string, string>;
    dataDir: z<string, string>;
    grokLogin: z<"pkce" | "device", "pkce" | "device">;
}>, Schemastery.ObjectT<{
    port: z<number, number>;
    provider: z<string, string>;
    dataDir: z<string, string>;
    grokLogin: z<"pkce" | "device", "pkce" | "device">;
}>>;
export declare function registerRpc(ctx: any, controller: any): void;
export declare function apply(ctx: any, config?: {}): void;
export { CODEX_CLIENT_ID, CODEX_AUTHORIZE_URL, CODEX_TOKEN_URL, CODEX_API_URL, CODEX_ORIGINATOR, CODEX_USER_AGENT, codexCredentialHeaders, } from './oauth/codex/index.js';
export { GROK_CLIENT_ID, GROK_DISCOVERY_URL, GROK_API_URL, GROK_USER_AGENT, GROK_LARGE_CONTEXT, GROK_REASONING_45, GROK_REASONING_46, grokCredentialHeaders, } from './oauth/grok/index.js';
export { GLM_CLIENT_ID, GLM_CODING_URL, GLM_AUTHORIZE_URL, GLM_APP_VERSION, GLM_USER_AGENT, glmDesktopHeaders, glmUpstreamHeaders, } from './oauth/glm/index.js';
export { KIRO_PORTAL_URL, KIRO_MODELS, kiroUsageHeaders, kiroSession, } from './oauth/kiro/index.js';
export { ANTIGRAVITY_CLIENT_ID, ANTIGRAVITY_API_URL, ANTIGRAVITY_STREAM_URL, antigravityRequestUserAgent, antigravityChatHeaders, } from './oauth/antigravity/index.js';
export { CURSOR_CLIENT_VERSION, CURSOR_MODELS, cursorChatHeaders, cursorSession, } from './oauth/cursor/index.js';
export { OLLAMA_MODELS, OLLAMA_CHAT_URL, ollamaSession, ollamaUpstreamHeaders, } from './apikey/ollama/index.js';
export { KIMI_CLIENT_ID, KIMI_MODELS, KIMI_CHAT_URL, kimiSession, kimiUpstreamHeaders, } from './oauth/kimi/index.js';
export { COPILOT_CLIENT_ID, COPILOT_MODELS, copilotChatUrl, copilotSession, copilotUpstreamHeaders, } from './oauth/copilot/index.js';
export { OAUTH_CREDENTIAL_REF, ModelSwitch } from './oauth/models.js';
export { defaultDataDir } from './oauth/store.js';
export { AuthController } from './oauth/controller.js';
export { applyFastMode, modelSupportsFastMode } from './utils/fast-mode.js';
export { CONTEXT_VARIANT_SUFFIX, codexLargeContext, applyContextMode, isCodex900kBase, peelContextSuffix, } from './utils/context-mode.js';
export { parseCodexUsage, parseGrokBilling, parseGlmQuota, parseKiroUsage, parseCursorPeriodUsage, parseKimiUsage, parseCopilotUsage, parseResetCredits, QuotaStore } from './oauth/quota.js';
export { formatPlanLabel, CODEX_PLAN_NAMES } from './oauth/plan.js';
export { REPO_URL, REPO_SLUG, installedVersion, fresherVersion, fetchLatest, localUpdateInfo, profileFromBaseUrl, pluginUpdateCommand, runPluginUpdate, applyHostUpdate, DSH_REPO_URL, DSH_REPO_SLUG, DSH_NPM_PACKAGE, localDshInfo, fetchDshLatest, dshUpdateCommand, dshInstallPrefix, applyHostDshUpdate, listDshInstallVersions, scheduleDshWebRestart, } from './utils/update.js';
