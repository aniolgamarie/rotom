# Cursor OAuth

本文件是 `src/oauth/cursor/` 的设计源。改登录、额度、对话或缓存先改这里再改代码。
跨家族硬约定在仓库根 [`AGENTS.md`](../../../AGENTS.md)；故障记录在 [`docs/error.md`](../../../docs/error.md)；对照仓库在 [`docs/oauth.md`](../../../docs/oauth.md)。

Cursor 订阅（Composer / Claude / GPT / Grok via Cursor infra）。原生 wire 是 **Connect RPC v1 protobuf over HTTP/2**，不是 OpenAI REST。社区逆向来自 MIT [`Rahularya01/pi-cursor`](https://github.com/Rahularya01/pi-cursor)（`src/auth/oauth.ts`、`docs/protocol.md`、`src/client/h2-session.ts`、`src/stream/request-build.ts`、`proto/agent.proto`）。缓存命中字段与 Run handshake 头对照 [`fitchmultz/pi-cursor-sdk`](https://github.com/fitchmultz/pi-cursor-sdk) 钉的 `@cursor/sdk@1.0.27`（`TurnEndedUpdate.cache_read_tokens`、`x-original-request-id`）。本目录只抽 Run / GetUsableModels / GetCurrentPeriodUsage 用到的字段，不 vendor 整棵树，也不引入 Bun / `@cursor/sdk`。

> 非正式集成。Cursor 随时可能改线。只用用户自己有权使用的账号。

## 文件

| 文件 | 职责 |
|---|---|
| [`index.ts`](index.ts) | 目录、身份、PKCE 参数、poll / refresh、CLI 指纹、session |
| [`catalog.ts`](catalog.ts) | 登录后 GetUsableModels + AvailableModels 活目录；静态 `CURSOR_MODELS` 只做离线 fallback |
| [`pkce-flow.ts`](pkce-flow.ts) | 打开 `loginDeepControl` + poll 直到 tokens |
| [`import.ts`](import.ts) | 本机 CLI Keychain / IDE `state.vscdb` / `CURSOR_ACCESS_TOKEN` |
| [`refresh-guard.ts`](refresh-guard.ts) | 已知坏 refresh 短退避，避免 stale CLI 卡住 snapshot |
| [`request.ts`](request.ts) | OpenAI Completions ↔ `AgentClientMessage` / `AgentServerMessage` |
| [`cache.ts`](cache.ts) | `AgentRunRequest.conversation_id` + 稳定 turn id。禁止 `Date.now()` / 每次 `randomUUID()` |
| [`proto.ts`](proto.ts) | 最小 protobuf + Connect framing（Run / GetUsableModels / AvailableModels） |
| [`h2-session.ts`](h2-session.ts) | Node `http2` 进程内会话（unary + streaming） |
| [`transport.ts`](transport.ts) | Completions HTTP / SSE 输出与 Run 事件消费背压 |

调度：[`../proxy.ts`](../proxy.ts) `family === 'cursor'` 剥 Codex retention，取出 `cursorConversationId`；真正组 Run 在 `openaiToCursor`。
额度：[`../quota.ts`](../quota.ts) `fetchCursorQuota` / `parseCursorPeriodUsage`（`api2.cursor.sh` JSON，不是 agentn）。
套餐：`CURSOR_PLAN_NAMES`（Free / Hobby / Pro / Pro+ / Business / Team / Ultra）。

## 协议

DSH `api: openai-completions`。原生 Connect/protobuf 对不上三种闭集，Completions + 翻译层是唯一划算的。不要改 Responses / Anthropic。

```text
DSH POST /cursor/v1/chat/completions
  → openaiToCursor
  → HTTP/2 POST https://agentn.us.api5.cursor.sh/agent.v1.AgentService/Run
     application/connect+proto
  → AgentServerMessage 流 → OpenAI SSE / JSON
```

`baseURL` 是 `${origin}/cursor`，Completions SDK 会打到 `/cursor/v1/chat/completions`。不要写成 `/cursor/v1`。

非流 Completions：Run 本身是流；hop **收集整段再回一条 JSON**。不是 Codex 那种 SSE-only 拒非流。

Run 握手必须按类型回帧，不能一律当原生工具拒绝：

- `ExecServerMessage.request_context_args` → `RequestContextResult.success`（带 DSH 的 `McpToolDefinition`，即 `requestContextArgs.tools`）。回 `ExecClientThrow` 会让上游直接判 `Failed to get request context`，任何模型都跑不起来。
- `kvServerMessage`：`getBlobArgs` 回 `getBlobResult`，`setBlobArgs` 回 `setBlobResult`（两者是不同的 oneof field）。
- 原生 Cursor 工具（`shell_args` / `read_args` / `ls_args` / `write_args` / …）回**类型化 rejection**（`Tool not available in this environment. Use the MCP tools provided instead.`），模型据此回退到 DSH 的 MCP 工具；不要用 throw，否则整轮失败。
- `mcp_args` → 把真实参数（`google.protobuf.Value` map）转成 OpenAI `tool_calls`，然后结束本轮 Run 交给 DSH 执行。

工具结果续跑：Cursor 没有无状态的 tool-result action。下一轮把**完成轮**（user + MCP 调用 + result）写进 `conversationState`（`parseTurns` 只在还有未答复 toolCall 时才算 in-flight），并把工具输出作为**当前 user 消息**（`openaiToCursor` 的 `continuationText`）。只重发原 user 文本会让模型重复调用同一个工具。

HTTP/2 请求取消 / unary 超时必须销毁该请求独占的连接，`close()` 的优雅关闭不会终止活动流；已结算后不再消费消息或写 KV 回复。预取消信号不建立连接。`onEvent` 的异步消费完成前暂停接收，SSE 背压沿调用链传回 Run。EOF 的 Connect 残帧必须报错；已输出后的异常发 OpenAI error SSE，不混入回答文字或追加 DONE。见[故障记录](../../../docs/error.md)。

## 登录

| 方法 | 用户看见 | 怎么登录 |
|---|---|---|
| PKCE poll | 主按钮 | 打开 `https://cursor.com/loginDeepControl?challenge=&uuid=&mode=login&redirectTarget=cli`，`GET https://api2.cursor.sh/auth/poll?uuid=&verifier=`。404 = 还在等，退避 1s→10s，最多约 150 次 |
| 本机导入 | 「导入本机 Cursor」 | 见下。**不是**第二套 OAuth |
| 空花名册自动导入 | 无按钮 | roster 为空时尝试一次本机复用。**绝不**覆盖已存 PKCE/session |

刷新：`POST https://api2.cursor.sh/auth/exchange_user_api_key`，`Authorization: Bearer <refresh>`，body `{}`。过期用 JWT `exp` 减 5 分钟。

**不要**在插件加载时静默扫 Keychain / `state.vscdb` 覆盖已有会话。自动导入只在 cursor 花名册为空时走一次。

### 卡抬头身份

可见标题只走人类 id，顺序：

1. JWT `email` / `preferred_username`（`cursorAccountFromToken`，不验签）
2. session `cachedEmail` / IDE `state.vscdb` `cursorAuth/cachedEmail`
3. `POST …/aiserver.v1.AuthService/GetEmail` `{ email }`（刷新额度必打；usage JSON 没有 email）
4. 必要时 `POST …/aiserver.v1.DashboardService/GetMe`（`email` 优先，否则 `firstName` + `lastName`）
5. `GetCurrentPeriodUsage` JSON `email`（有才用；活探测里没有）

`displayCursorAccount` / `publicSession('cursor')` **永不**展示 JWT `sub`、字面 `cursor`、`provider|user_*`（WorkOS / Auth0）。没有人类 id 就省略标题（`undefined`），不要用 opaque id 顶上去。

`accountIdOf` 仍可用 JWT `sub` 当 vault 稳定键。刷新 / snapshot 读到人类 id 就写 `cachedEmail`，opaque vault 走 `replaceAccountId`（同 GLM `zcode`）。不要打 `cursor.com/api/auth/me`（204）或 cookie 的 usage-summary（401）。

### 本机导入（用户拥有的 Cursor 登录复用）

顺序：

1. `CURSOR_ACCESS_TOKEN`（不 refresh）
2. 并行读 Keychain 与 vscdb
3. 仍有效的本地 access（先 Keychain 再 vscdb）—— **零网络**
4. 否则 refresh Keychain；失败且 vscdb refresh 不同再 refresh vscdb
5. `saveSession`，`source` 标 `cli_keychain` / `ide_vscdb` / `env`
6. 刷新额度

macOS Keychain（仅 darwin，`execFile` 超时 2s，并发）：

```text
security find-generic-password -s cursor-access-token -a cursor-user -w
security find-generic-password -s cursor-refresh-token -a cursor-user -w
```

IDE `state.vscdb`（只读，`node:sqlite` `DatabaseSync`，用完 close）：

- macOS: `~/Library/Application Support/Cursor/User/globalStorage/state.vscdb`
- Windows: `%APPDATA%/Cursor/User/globalStorage/state.vscdb`
- Linux: `~/.config/Cursor/User/globalStorage/state.vscdb`
- WSL: **仅当前** Windows 用户（`USERPROFILE` / `USERNAME` → `/mnt/c/Users/<you>/AppData/Roaming/Cursor/...`）。不扫 Public / Default / 其他 profile。

键：`cursorAuth/accessToken`、`cursorAuth/refreshToken`、`cursorAuth/cachedEmail`（可选，给卡抬头）。缺文件 = 空，不把堆栈抛给 UI。

空结果：zh「本机没有 Cursor CLI 或 IDE 登录」。Keychain 第一次读可能弹系统授权；vscdb 键名可能被 Cursor 改掉——见 `docs/error.md`。

## 指纹

AgentService/Run 与 unary 发 Cursor **CLI** 头。CLI 版本对齐 [Rahularya01/pi-cursor](https://github.com/Rahularya01/pi-cursor) `DEFAULT_CURSOR_CLIENT_VERSION`（`cli-2026.07.23-e383d2b`）。`x-original-request-id` 对齐 `@cursor/sdk` Run handshake。本 hop 是 `loginDeepControl` OAuth，**不要**改成 `x-cursor-client-type: sdk`（那是 API key 的 `Agent.create`）。

| 头 | 值 |
|---|---|
| `authorization` | `Bearer <access>` |
| `connect-protocol-version` | `1` |
| `content-type` | 流 `application/connect+proto`；unary `application/proto` |
| `te` | `trailers` |
| `x-ghost-mode` | `true` |
| `x-cursor-client-version` | `cli-2026.07.23-e383d2b`（`PI_CURSOR_CLIENT_VERSION` 可覆盖） |
| `x-cursor-client-type` | `cli` |
| `x-request-id` | 每条 DSH 请求一个 UUID |
| `x-original-request-id` | 与 `x-request-id` 相同（DSH 一轮就是一次 Run；重试保持原 id） |

不要假装 Cursor 桌面 IDE。不要发明 `x-parent-request-id` / `x-root-parent-request-id` / `x-parent-agent-tool-call-id`（官方 SDK 给子 agent 用，本 hop 不发）。`conversationState.client_name` 用 `dsh`。

## 模型

静态 fallback（离线 / RPC 空）对齐 [cursor.com/docs/models-and-pricing](https://cursor.com/docs/models-and-pricing)：`composer-2.5`、`grok-4.6`、`grok-4.5`、`composer-2`、`composer-1.5`、`claude-fable-5-1`、`claude-opus-5`、`claude-sonnet-5`、`gemini-3.1-pro`、`gemini-3.8-flash`、`gpt-5.6-sol` / `terra` / `luna`、`gpt-5.5`。id 抄官方 Model ID（Fable 是 `claude-fable-5-1`，不是点号）。登录、本机导入、额度刷新之后走活发现，**叠在静态楼上**（Kiro 同款 merge，不再整表替换）：

```text
unary GetUsableModels  agentn  /agent.v1.AgentService/GetUsableModels
unary AvailableModels  api2    /aiserver.v1.AiService/AvailableModels
  → 按 access-token sha256 前 16 位缓存 5 分钟
  → toCursorPickerModels 收成一行 / 家族；有 `-fast` 源时再加 `{family}-fast`
  → mergeCursorStaticFloor 把活家族叠在静态楼上
  → buildProviders / catalog / llm-pi-ai yaml
```

`AvailableModels` 用现有 proto 编解码，不加 Bun。任一 RPC 失败或空列表 **不挡对话**，回落静态楼。活列表非空也不丢掉官方行（GetUsableModels 仍是旧 5 个时，Composer 2.5 / Grok 4.6 等仍在勾选格）。

不要把 pi-cursor `catalog.json` 的 ~100 个 effort/fast/thinking/max-mode id 铺进 Settings 勾选格。`cursorPickerFamilyId` 剥那些后缀，DSH `reasoningEfforts` 键只有 `off|low|medium|high|xhigh`（值 `off: "none"`，`xhigh: "extra-high"`）。Tab / chat 内部变体隐藏（Pi `/cursor.models all` 才是 opt-in）。账号有 `default` / `auto` 就留一行 id `default`，显示名 **Cursor Auto**（zh/en 同名，不翻译 Auto；wire 仍是 `default`）。窗口优先活 metadata，否则 `inferCursorContextWindow` / `inferCursorMaxOutputTokens`。

活目录里某个家族只要有一条源 id 在剥掉 effort / thinking / max-mode 之后仍带 `-fast`（`gpt-5.5-high-fast`、`composer-2-fast`），选择器再加一行 `{family}-fast`，显示名 `{Name} Fast`（zh/en 都不译 Fast）。`default` / Auto 不加 Fast。没有 `-fast` 源的家族不加。静态楼不编 Fast（官方 Fast 只在活源有 `-fast` 时出现）。不要用 Codex `src/utils/fast-mode.ts` / `service_tier: priority`。

Hop：Completions `model` 以 `-fast` 结尾时，`requestedModel.modelId` 是家族 id（`gpt-5.5`，不是 `gpt-5.5-high-fast`），`modelParameters` 在已有 `{ id: 'reasoning', value }` 之外再加 `{ id: 'fast', value: 'true' }`（pi-cursor `RequestedModel.parameters` 的 Fast 字段，与 reasoning 同一条路）。`maxMode` 仍是 false。对话 pin 跟家族 id，Fast 不是另一段 conversation。

Settings 勾选仍须登录后才能改。新发现的行默认开，`setModels` / `sync()` 写入 `settings.yaml` `oauth-cursor.models`。

## 额度

刷新额度并行三路（host 都是 **api2**，不是 agentn，也不是 cursor.com）：

```text
POST /aiserver.v1.DashboardService/GetCurrentPeriodUsage  {}
GET  /auth/full_stripe_profile
POST /aiserver.v1.AuthService/GetEmail                    {}
  → 无邮箱再 POST /aiserver.v1.DashboardService/GetMe     {}
```

套餐优先 stripe `individualMembershipType` / `membershipType`，再 usage `membershipType`，缺省才是 Pro。IDE Ultra 活探测 usage 没有 membershipType，必须读 stripe。

两条 `kind: 'product'`，对齐 Cursor 仪表盘百分比（不是 `includedSpend/limit` 美分封顶）。`0.454` 是 0.454 **百分**，不是分数。`clampUsedPct`：已用 > 0 且四舍五入成 0 则显示 1（对上 Cursor「1% API」）。

| `product` | 字段 | zh | en |
|---|---|---|---|
| `auto` | `planUsage.autoPercentUsed` | 补全 & Composer | Tab completion & Composer |
| `api` | `planUsage.apiPercentUsed` | API 调用 | API |

缺字段当 0%（刚重置不是缺条）。`resetAt` 两边都取 `billingCycleEnd`。Settings 一律 `RemainingBar` / `QuotaMeter`：填充 = `remainingPercent`（`100 − used`），文案 `剩余 {n}%`。PKCE 真 0/0 → 剩余 100%。`formatPlanLabel(..., 'cursor')` 的 `pro` 是 Pro，`ultra` 是 Ultra，不是 Codex Pro 20x。

## 缓存

| | |
|---|---|
| 后端 | Cursor Agent 会话（`AgentRunRequest.conversation_id`）。prefix 是 conversationState blobs |
| 粘性 id | DSH `session_id` / `prompt_cache_key` **加上 model**；缺 pin 时 `dsh-cursor:<model>`（裸 `dsh-cursor` 只在没有 model 时）。禁止 `Date.now()`。历史 turn 的 `messageId` / `requestId` 用内容哈希，禁止每跳 `randomUUID()` |
| HTTP | `x-request-id` = `x-original-request-id`（SDK handshake）。不写 Codex `session-id` / Grok `x-grok-conv-id` |
| 停额外 snapshot | 第一条 system 钉在 `root_prompt_messages_json`；后续 DSH snapshot 再追加一条 system blob（Cursor 前缀列表，不是 GLM 尾 system，也不是 Gemini 尾 user） |
| 命中字段 | `TurnEndedUpdate.cache_read_tokens`（field 3）→ OpenAI `prompt_tokens_details.cached_tokens`。`input_tokens` 是整段 prompt（含 cache），与 `@cursor/sdk` `toTokenUsage` 一致 |

不写 Codex `session-id` / `prompt_cache_key`，不写 Grok `x-grok-conv-id`。

## 不要

- 从 Codex / Grok / GLM / Kiro / Antigravity 抄 cache helper
- 对 `requestContextArgs` / KV set / 原生工具统一回 `ExecClientThrow`（任一都会让整轮 Run 失败）
- 工具结果只重发原 user 文本、不把完成轮写进 `conversationState`（模型会重复调用同一工具）
- 用 Responses 或 Anthropic 当 DSH `api`
- 插件加载时静默收割 IDE / Keychain 覆盖已有 PKCE
- 打印或提交 token
- 加 Bun
- 发明 `requestType` / boost 字段
- 把 pi-cursor `catalog.json` 的 effort/fast/thinking/max-mode 变体铺进勾选格
- 用 `includedSpend` / `limit` 当额度条 used/total
- 恢复 `src/utils/cache-session.ts`
- 扫 WSL / Windows 上别人的 Users 目录
- 打 `cursor.com/api/auth/me` 或 cookie `usage-summary`（204 / 401）
- 发明 `x-parent-request-id` / `x-root-parent-request-id` / `x-cursor-client-type: sdk`（官方 SDK 有，本 hop 是 CLI OAuth 不发）
- 把 JWT `sub` / `cursor` / `provider|user_*` 画在 Settings 卡抬头
- 把 `apiPercentUsed` 0–1 当分数（0.454 不是 45%）

## 归因

Wire / PKCE / Keychain+vscdb 顺序改编自 MIT：

- [Rahularya01/pi-cursor](https://github.com/Rahularya01/pi-cursor)
- [ephraimduncan/opencode-cursor](https://github.com/ephraimduncan/opencode-cursor)

`TurnEndedUpdate` 字段号、`cacheReadTokens` 分区、`x-original-request-id` 对照：

- [fitchmultz/pi-cursor-sdk](https://github.com/fitchmultz/pi-cursor-sdk)（`@cursor/sdk@1.0.27`）

总表见 [`docs/oauth.md`](../../../docs/oauth.md)。
pi-cursor-sdk 走 API key + `Agent.create`，本 hop 仍是 CLI OAuth，不要改 `x-cursor-client-type: sdk`。
