# Rotom：Pi Base / Full 双 Profile 与 Codex 持续实施任务包

设计日期：2026-10-03。

本包将用户最新的两项要求合并：两个独立但共享基础的 Pi 产品，以及 Codex 长任务的持续推进与可核对验收。它是计划和实施输入，未修改 Rotom、未安装任何插件或 hook、未执行本机账号/性能测试。

## 文件

- CODEX_IMPLEMENTATION_PROMPT.md：给 Codex 的完整执行指令。
- PLAN.md：两个 profile、有限首版范围、架构边界与实施顺序。
- ACCEPTANCE.md：共同、Base、Full、实施过程的验收矩阵，初始均未执行。
- STOP_GATE_SPEC.md：可选、用户信任后启用的项目级完成门禁规格，不是已运行的脚本。
- START_AND_RESUME.md：启动任务与真实中断后的恢复指令。

不需要读完所有文件后再手工选插件。将它们交给本地 Codex，要求按启动指令实施即可。不存在 `pi-base` 或 `pi-full` 原生参数的预设，执行器需根据 Rotom 实际接口实现并验证入口。

## 本版取代的旧约束

基础版不再必须含子代理。允许两个长期、同代维护的 profile；旧兼容环境只做一次性回退。Full 完整交付不等于全量常驻，基础通过后仍继续其剩余工作。Task Keeper、model-delegate、Durable 的实现保留在 Full 范围，不能吞掉基础体验建设，也不能只作为未来路线图交付。

## 依据与资料入口

附件基础：上一版 CODEX_IMPLEMENTATION_PROMPT.md、PLAN.md、ACCEPTANCE.md。本包保留其证据、认证、最小修改与状态保护原则；双 profile 范围与持续执行规则按用户最新要求修改。

外部事实在 2026-10-03 核对，以下页面会变化，实施时按本机版本再次核实：

1. OpenAI：Using PLANS.md for multi-hour problem solving。
   https://developers.openai.com/cookbook/articles/codex_exec_plans
   支持长期任务的自包含动态计划与阶段验证。本包是适配设计，没有照抄完整官方模板或其提交策略。
2. OpenAI：Hooks。
   https://developers.openai.com/codex/hooks
   Stop 的继续机制、用户信任、配置加载与 Interrupt 边界；本机支持必须测试。
3. OpenAI：Codex CLI 与非交互模式。
   https://developers.openai.com/codex/cli/features
   https://developers.openai.com/codex/noninteractive
   原生会话恢复，不代表操作系统进程恢复。
4. OpenAI：Subagents。
   https://developers.openai.com/codex/multi-agent
   适合独立调查与审查；并行写入须管理冲突和额外开销。
5. Pi：Settings。
   https://raw.githubusercontent.com/earendil-works/pi/main/packages/coding-agent/docs/settings.md
   用户与项目的资源加载和覆盖需实际审计；不能仅凭一个 profile 标签判定隔离。
6. Pi Durable README。
   https://raw.githubusercontent.com/earendil-works/pi/main/packages/durable/README.md
   实验性状态及持久任务原语。本文的整合服务和工具是拟议实现，不是官方即插即用插件。
7. Claude Code Best Practices。
   https://code.claude.com/docs/en/best-practices
   以可执行验证、上下文控制和按需协作为对照，而非以工具数量衡量质量。
8. Rotom 与 Pi 生态入口，供实施时重新研究，不代表本轮完成新的源码审计。
   https://github.com/aniolgamarie/rotom
   https://github.com/earendil-works/pi/releases
   https://pi.dev/packages

最终标准：两个 profile 可实际使用，基础不被高级依赖拖累；阶段不被误当总完成；真实阻塞如实报告，不能靠无限重试或伪造通过保持“持续运行”。
